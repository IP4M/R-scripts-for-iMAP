# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/6/18

my.test <- function(formula, data, method, paired) {
  p <- 1
  if (method == "wilcox.test") {
    test <- wilcox.test(formula = formula, data = data, paired = paired)
    p <- test$p.value
  }else {
    test <- kruskal.test(formula = formula, data = data)
    p <- test$p.value
  }
  list(p = p)
}

configGet <- function(configData, key) {
  configData %>%
    filter(arg == key) %>%
    .$value
}

library(gridExtra)
library(ggpubr)
library(egg)
library(lemon)
library(optparse)
library(tidyverse)
library(magrittr)
library(scales)
library(ggrepel)
library(extrafont)

createWhenNoExist <- function(f) {
  !dir.exists(f) && dir.create(f)
}

option_list <- list(
  make_option("--i", default = "AllMet.csv", type = "character", help = "metabolite data file"),
  make_option("--g", default = "group.txt", type = "character", help = "sample group file"),
  make_option("--sc", default = "", type = "character", help = "sample color file"),
  make_option("--cc", default = "calculate_config.txt", type = "character", help = "config file"),
  make_option("--pc", default = "", type = "character", help = "config file")
)
opt <- parse_args(OptionParser(option_list = option_list))

if (!file.exists(opt$sc)) {
  file.copy("Class_Color.txt", opt$sc)
}

options(digits = 3)
font_import(paths = c("/usr/share/fonts/myFonts"), recursive = F, prompt = F)

args <- commandArgs(trailingOnly = F)
scriptPath <- dirname(sub("--file=", "", args[grep("--file", args)]))
source(str_c(scriptPath, "/parse_config.R"))
baseFamily <- fontFamily

sampleInfo <- read_tsv(opt$g) %>%
  rename(SampleID = Sample) %>%
  mutate(ClassNote = as.character(ClassNote))

groupNum <- length(unique(sampleInfo$ClassNote))

if (groupNum < 2) {
  quit(status = 0)
}

calculateConfigData <- read_tsv(opt$cc, col_names = F, col_types = "cc") %>%
  set_colnames(c("arg", "value"))

isPaired <- configGet(calculateConfigData, "isPaired") != "None"

parent <- "./"
createWhenNoExist(parent)
fileName <- paste0(parent, "/PCA_Score_with_Boxplot_with_Points.pdf")

pdf(fileName, width = width, height = height)

pcDataFileName <- paste0(parent, "/PCA_Score.csv")

xPc <- x %>%
  str_c("PC", .)
yPc <- y %>%
  str_c("PC", .)

pc12 <- read_csv(pcDataFileName) %>%
  rename(SampleID = X1) %>%
  select(c("SampleID", xPc, yPc)) %>%
  set_colnames(c("SampleID", "xPc", "yPc")) %>%
  left_join(sampleInfo, by = c("SampleID")) %>%
  mutate(ClassNote = factor(ClassNote, levels = unique(sampleInfo$ClassNote))) %>%
  arrange(ClassNote)

if (isPaired) {
  pc12 <- pc12 %>%
    arrange(Pair_ID)
}

parameterFileName <- paste0(parent, "/PCA_R2.csv")
parameterData <- read.csv(parameterFileName, header = T, stringsAsFactors = F, comment.char = "")

impoPc1 <- parameterData[1, xPc]
impoPc1 <- round(impoPc1 * 100, 2)
impoPc2 <- parameterData[1, yPc]
impoPc2 <- round(impoPc2 * 100, 2)

top <- 0.2
left <- 0.3
right <- 0.2

sampleColDf <- read_tsv(opt$sc) %>%
  select(c("ClassNote", "col"))

sampleCols <- sampleColDf %>%
  deframe()

p <- ggplot(pc12, mapping = aes(x = xPc, y = yPc, label = SampleID)) +
  xlab(paste("PC1(", impoPc1, "%)", sep = "")) +
  ylab("") +
  theme_bw(base_size = 8.8, base_family = baseFamily) +
  theme(axis.text.x = element_text(size = 11, vjust = 0.5), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), axis.text.y = element_text(size = 11, angle = 90), legend.position = "none",
        axis.title.y = element_text(size = 11), axis.title.x = element_text(size = 12),
        panel.border = element_rect(size = 0.75), plot.margin = unit(c(top, right, 0.5, left), "cm")
  ) +
  #0 line
  geom_vline(aes(xintercept = 0), colour = "#BEBEBE", linetype = "solid") +
  geom_hline(aes(yintercept = 0), colour = "#BEBEBE", linetype = "solid") +
  #point
  geom_point(aes(colour = factor(ClassNote)), size = 4, stroke = 0) +
  #lengend
  scale_colour_manual("", values = sampleCols)

if (showSample) {
  p <- p +
    geom_text_repel(segment.size = 0.2, size = 2, family = baseFamily)
}

if (showEllipse) {
  p <- p +
    stat_ellipse(colour = "#BEBEBE", size = 0.3, level = 0.95, type = "norm")
}


axisInfo <- ggplot_build(p)$layout$panel_params[[1]]
ylabels <- axisInfo$y.labels
yBreaks <- ylabels %>% as.numeric()
ylim <- axisInfo$y.range
xlabels <- axisInfo$x.labels
xBreaks <- xlabels %>% as.numeric()
xlim <- axisInfo$x.range

isMulti <- length(unique(pc12$ClassNote)) > 2

method <- if (isMulti) {
  "kruskal.test"
}else "wilcox.test"
pBeforeStr <- ""

rTest <- my.test(yPc ~ ClassNote, data = pc12, method = method, paired = isPaired)
rPValue <- rTest$p %>% round(3)
if (rPValue == 0) {
  rPValue <- rTest$p %>% scientific(digits = 3)
}

rBoxPlot <- ggplot(pc12, mapping = aes(x = ClassNote, y = yPc, fill = ClassNote)) +
  theme_bw(base_size = 8.8, base_family = baseFamily) +
  theme(axis.text.y = element_text(size = 8.8), legend.position = 'none', axis.title.y = element_text(size = 11),
        legend.margin = margin(t = 0.3, b = 0.1, unit = 'cm'), legend.text = element_text(size = 6),
        axis.title.x = element_text(size = 12), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        axis.ticks.x = element_blank(), panel.border = element_rect(size = 0.75),
        plot.margin = unit(c(top, right, 0.5, left), "cm")
  ) +
  geom_boxplot() +
  geom_jitter() +
  #lengend
  scale_fill_manual("", values = sampleCols) +
  scale_x_discrete(paste0(pBeforeStr, "Pvalue=", rPValue), labels = rep("", length(pc12$ClassNote)), breaks = pc12$ClassNote) +
  scale_y_continuous(str_c("PC2(", impoPc2, "%)"), limits = ylim, expand = c(0, 0))

bTest <- my.test(xPc ~ ClassNote, data = pc12, method = method, paired = isPaired)
bPValue <- bTest$p %>% round(3)
if (bPValue == 0) {
  bPValue <- bTest$p %>% scientific(digits = 3)
}

bBoxPlot <- ggplot(pc12, mapping = aes(x = ClassNote, y = xPc, fill = ClassNote)) +
  xlab("") +
  ylab("") +
  theme_bw(base_size = 8.8, base_family = baseFamily) +
  theme(axis.text.x = element_text(size = 9, vjust = 0.5), panel.border = element_rect(size = 0.75),
        axis.text.y = element_blank(), legend.position = 'none', axis.ticks.y = element_blank(),
        axis.title.y = element_text(size = 12), legend.margin = margin(t = 0.3, b = 0.1, unit = 'cm'),
        legend.text = element_text(size = 6), axis.title.x = element_text(size = 12), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), plot.title = element_text(size = 12),
        plot.margin = unit(c(top, right, 0.5, left), "cm")
  ) +
  geom_boxplot() +
  geom_jitter() +
  coord_flip() +
  scale_fill_manual("", values = sampleCols) +
  ggtitle(paste0(pBeforeStr, "Pvalue=", bPValue)) +
  scale_y_continuous("", limits = xlim, expand = c(0, 0))


legend <- g_legend(p + theme(legend.position = 'left', legend.text = element_text(size = legendFont),
                             legend.margin = margin(t = -2, unit = 'cm'))
)

gA <- ggplotGrob(p)
gB <- ggplotGrob(bBoxPlot)
maxWidth = grid::unit.pmax(gA$widths[2:5], gB$widths[2:5])
gA$widths[2:5] <- as.list(maxWidth)
gB$widths[2:5] <- as.list(maxWidth)

grid.arrange(gA, rBoxPlot, gB, legend, ncol = 2, widths = c(0.75, 0.25), heights = c(0.75, 0.25), newpage = F)

dev.off()
