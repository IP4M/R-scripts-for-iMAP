# Title     : TODO
# Objective : TODO
# Created by: yz
# Created on: 2018/3/1

createWhenNoExist <- function(f) {
  !dir.exists(f) && dir.create(f)
}

library(optparse)
library(magrittr)
library(tidyverse)

option_list <- list(
  make_option("--pc", default = "", type = "character", help = "config file")

)
opt <- parse_args(OptionParser(option_list = option_list))

args <- commandArgs(trailingOnly = F)
scriptPath <- dirname(sub("--file=", "", args[grep("--file", args)]))
source(str_c(scriptPath, "/base.R"))
source(str_c(scriptPath, "/parse_config.R"))

load("enrich_mSet.RData")

parent <- "./"
createWhenNoExist(parent)

if (!is.numeric(inMset)) {
  mSetObj <- inMset
  folds <- mSetObj$analSet$ora.mat[, 3] / mSetObj$analSet$ora.mat[,
    2]
  names(folds) <- GetShortNames(rownames(mSetObj$analSet$ora.mat))
  pvals <- mSetObj$analSet$ora.mat[, 4]

  if (!.on.public.web) {
    g <- mSetObj$analSet$enrich.net <- PlotEnrichNet.Overview(folds,
                                                              pvals, parent = parent)
    if (is.null(g)) {
      return(.set.mSet(mSetObj))
    }
    pdf(str_c(parent, "/Network.pdf"), width, height)
    plot(g, layout = layout.fruchterman.reingold)
    dev.off()
  }


}


