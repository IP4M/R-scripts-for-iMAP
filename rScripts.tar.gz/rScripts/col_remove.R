# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/8/12
library(optparse)
library(magrittr)
library(impute)
library(tidyverse)

option_list <- list(
  make_option("--cc", default = "calculate_config.txt", type = "character", help = "config file"),
  make_option("--si", default = "1;0", type = "character", help = "step and config arg index")
)
opt <- parse_args(OptionParser(option_list = option_list))

args <- commandArgs(trailingOnly = F)
scriptPath <- dirname(sub("--file=", "", args[grep("--file", args)]))
source(str_c(scriptPath, "/base.R"))

calculateConfigData <- read_tsv(opt$cc, col_names = F, col_types = "cc") %>%
  set_colnames(c("arg", "value"))
calculateConfigData

colNaRates <- configGet(calculateConfigData, "colNaRates") %>%
  str_split(";") %>%
  unlist() %>%
  as.numeric()
si <- opt$si %>%
  str_split(";") %>%
  unlist()
step <- si[1] %>%
  as.numeric()
index <- si[2] %>%
  as.numeric()
colNaRate <- colNaRates[index + 1] / 100
colNaRate

data <- read_tsv(str_c(step - 1, ".result.txt")) %>%
  rename(Metabolite = 1)

filterColNames <- data %>%
  summarise_at(vars(-c("Metabolite")), function(x) {
    mean(x == 0)
  }) %>%
  select_if(function(x) {
    x <= colNaRate
  }) %>%
  colnames()

filterColNames

outData <- data %>%
  select(c("Metabolite", tidyselect::all_of(filterColNames)))

write_tsv(outData, str_c(step, ".result.txt"))
write_csv(outData, str_c(step, ".sample_remove.csv"))








