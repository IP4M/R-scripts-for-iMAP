# Title     : TODO
# Objective : TODO
# Created by: yz
# Created on: 4/9/2020

configGet <- function(configData, key) {
  configData %>%
    filter(arg == key) %>%
    .$value
}

getPlotConfigData <- function(pcFile) {
  read_tsv(pcFile, col_names = F, col_types = "cc") %>%
    set_colnames(c("arg", "value"))
}

getFinalWidth <- function(width, defaultWidth, pcFile) {
  if (width == 0) {
    plotConfigData <- getPlotConfigData(pcFile) %>%
      filter(arg != "width") %>%
      add_row(arg = "width", value = str_c(defaultWidth))
    write_tsv(plotConfigData, pcFile, col_names = F)
    defaultWidth
  }else {
    width
  }
}

getFinalHeight <- function(height, defaultHeight, pcFile) {
  if (height == 0) {
    plotConfigData <- getPlotConfigData(pcFile) %>%
      filter(arg != "height") %>%
      add_row(arg = "height", value = str_c(defaultHeight))
    write_tsv(plotConfigData, pcFile, col_names = F)
    defaultHeight
  }else {
    height
  }
}

plotConfigData <- read_tsv(opt$pc, col_names = F, col_types = "cc") %>%
  set_colnames(c("arg", "value"))

x <- configGet(plotConfigData, "x")
y <- configGet(plotConfigData, "y")
z <- configGet(plotConfigData, "z")
width <- configGet(plotConfigData, "width") %>%
  as.numeric()
height <- configGet(plotConfigData, "height") %>%
  as.numeric()
showSample <- configGet(plotConfigData, "showSample") %>%
  as.logical()
showEllipse <- configGet(plotConfigData, "showEllipse") %>%
  as.logical()
xFont <- configGet(plotConfigData, "xFont")
xTitleFont <- configGet(plotConfigData, "xTitleFont")
yFont <- configGet(plotConfigData, "yFont")
yTitleFont <- configGet(plotConfigData, "yTitleFont")
mainTitle <- configGet(plotConfigData, "mainTitle")
mainTitleFont <- configGet(plotConfigData, "mainTitleFont")
legendFont <- configGet(plotConfigData, "legendFont")
legendTitle <- configGet(plotConfigData, "legendTitle")
legendTitleFont <- configGet(plotConfigData, "legendTitleFont")
r2xColor <- configGet(plotConfigData, "r2xColor")
r2yColor <- configGet(plotConfigData, "r2yColor")
q2Color <- configGet(plotConfigData, "q2Color")
q2yColor <- configGet(plotConfigData, "q2yColor")
rowCluster <- configGet(plotConfigData, "rowCluster") != "F"
rowClusterMethod <- configGet(plotConfigData, "rowClusterMethod")
colCluster <- configGet(plotConfigData, "colCluster") != "F"
colClusterMethod <- configGet(plotConfigData, "colClusterMethod")
colorsStr <- configGet(plotConfigData, "colorsStr")
customColors <- configGet(plotConfigData, "customColors")
finalColorsStr <- if (colorsStr == "custom") {
  customColors
} else {
  colorsStr
}
finalColors <- str_split(finalColorsStr, ":") %>%
  unlist()
naColor <- configGet(plotConfigData, "naColor")
showRowName <- configGet(plotConfigData, "showRowName") %>%
  as.logical()
showColName <- configGet(plotConfigData, "showColName") %>%
  as.logical()
xRotate <- configGet(plotConfigData, "xRotate") %>%
  as.numeric()
yRotate <- configGet(plotConfigData, "yRotate") %>%
  as.numeric()
rowTreeHeight <- configGet(plotConfigData, "rowTreeHeight")
colTreeHeight <- configGet(plotConfigData, "colTreeHeight")
fontFamily <- configGet(plotConfigData, "fontFamily")


print(showSample)

getBasicPlotArg <- function(p) {
  p <- p +
    theme(plot.title = element_text(hjust = 0.5, size = mainTitleFont), legend.text = element_text(size = legendFont),
          legend.title = element_text(size = legendTitleFont), axis.text.x = element_text(size = xFont),
          axis.title.x = element_text(size = xTitleFont), axis.text.y = element_text(size = yFont),
          axis.title.y = element_text(size = yTitleFont))

  if (!is.na(mainTitle)) {
    p <- p + ggtitle(mainTitle)
  }

  p
}

