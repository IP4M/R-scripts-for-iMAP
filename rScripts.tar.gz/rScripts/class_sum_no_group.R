# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/6/18

createWhenNoExist <- function(f) {
  !dir.exists(f) && dir.create(f)
}

library(gplots)
library(Hmisc)
library(optparse)
library(ropls)
library(magrittr)
library(scales)
library(tidyverse)

option_list <- list(
  make_option("--i", default = "AllMet_with_Anno.csv", type = "character", help = "metabolite data file"),
  make_option("--sc", default = "sample_color.txt", type = "character", help = "sample color file")
)
opt <- parse_args(OptionParser(option_list = option_list))

allData <- read_csv(opt$i) %>%
  select(-c("HMDB", "KEGG", "Metabolite")) %>%
  group_by(Class) %>%
  summarise_all(sum)

head(allData)

parent <- "./"
fileName <- paste0(parent, "Class_Table.csv")
data <- allData
write.csv(data, fileName, row.names = F)


