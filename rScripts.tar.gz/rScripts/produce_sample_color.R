# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/8/12
library(optparse)
library(tidyverse)

gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}

getSampleCols <- function(n) {
  inCols <- c("green", "blue")
  extraColors <- c("#CD0000", "#3A89CC", "#769C30", "#D99536", "#7B0078", "#BFBC3B", "#6E8B3D", "#00688B", "#C10077", "#CAAA76",
                   "#EEEE00", "#458B00", "#8B4513", "#008B8B", "#6E8B3D", "#8B7D6B", "#7FFF00", "#CDBA96", "#ADFF2F")
  orignalCols <- c(inCols, extraColors)
  on <- length(orignalCols)
  if (n <= on) {
    orignalCols[1:n]
  }else {
    ggCols <- gg_color_hue(n - on)
    c(orignalCols, ggCols)
  }
}

getNextColor <- function(curJ) {
  j <- curJ
  inCols <- c("green", "blue")
  extraColors <- c("#CD0000", "#3A89CC", "#769C30", "#D99536", "#7B0078", "#BFBC3B", "#6E8B3D", "#00688B", "#C10077", "#CAAA76",
                   "#EEEE00", "#458B00", "#8B4513", "#008B8B", "#6E8B3D", "#8B7D6B", "#7FFF00", "#CDBA96", "#ADFF2F")
  orignalCols <- c(inCols, extraColors)
  on <- length(orignalCols)
  if (j <= on) {
    orignalCols[j]
  }else {
    ggCols <- gg_color_hue(j - on)
    ggCols[j - on]
  }
}

getClassCols <- function(n) {
  inCols <- c("#00FFFF", "#0099FF", "#8A4198", "#FF6F00", "#CC9999", "#FFFF00", "#00FF7F", "#999999", "#CCFFCC", "#336666",
              "#FF6666", "#FFCC33", "#CC3399")
  extraColors <- c("#CD0000", "#3A89CC", "#769C30", "#D99536", "#7B0078", "#BFBC3B", "#6E8B3D", "#00688B", "#C10077", "#CAAA76",
                   "#EEEE00", "#458B00", "#8B4513", "#008B8B", "#6E8B3D", "#8B7D6B", "#7FFF00", "#CDBA96", "#ADFF2F")
  orignalCols <- c(inCols, extraColors)
  on <- length(orignalCols)
  if (n <= on) {
    orignalCols[1:n]
  }else {
    ggCols <- gg_color_hue(n - on)
    c(orignalCols, ggCols)
  }
}

option_list <- list(
  make_option("--g", default = "SampleInfo.csv", type = "character", help = "sample group file"),
  make_option("--sc", default = "sample_color.txt", type = "character", help = "sample color file"),
  make_option("--solution", default = "color_solution_1.txt", type = "character", help = "color solution file")
)
opt <- parse_args(OptionParser(option_list = option_list))

if (file.exists(opt$sc)) {
  quit(status = 0)
}

allClassNotes<-read_tsv(opt$g) %>%
  .$ClassNote %>%
  unique()

classNotes <- allClassNotes  %>%
  discard(~.x == "QC")

classNotes

colors <- read_csv(opt$solution, col_names = F) %>%
  .$X1


tbf <-if("QC" %in% allClassNotes){
  tibble(ClassNote = c("QC"), col = c("#ffd700"))
}else{
  tibble(ClassNote=character(),col=character())
}


curJ <- 1
for (i in 1:length(classNotes)) {
  classNote <- classNotes[i]
  color <- colors[i]
  if (is.na(color)) {
    color <- getNextColor(curJ)
    curJ <- curJ + 1
    while (color %in% tbf$col) {
      curJ <- curJ + 1
      color <- getNextColor(curJ)
    }
  }
  tbf <- tbf %>%
    add_row(ClassNote = classNote, col = color)
}

write_tsv(tbf, "Class_Color.txt")


