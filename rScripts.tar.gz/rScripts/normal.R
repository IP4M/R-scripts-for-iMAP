# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/8/12
library(optparse)
library(magrittr)
library(impute)
library(tidyverse)

option_list <- list(
make_option("--t", default = "normal", type = "character", help = "normal method"),
make_option("--ir", default = "", type = "character", help = "inner nomal meta name"),
make_option("--config", default = "config.csv", type = "character", help = "config file")
)
opt <- parse_args(OptionParser(option_list = option_list))

configData <- read_tsv(opt$config) %>%
    set_colnames(c("arg", "value"))

configData

data <- read.csv("02_AllMet_Raw_Missing_Value_Filled.csv", header = T, stringsAsFactors = F, row.names = 1) %>%
rownames_to_column("Raw_Metabolite")

rate <- 10000
if (opt$t == "normal") {
    data <- data %>%
    mutate_at(vars(- c("Raw_Metabolite")), function(x){
        sum <- sum(x)
        x * rate / sum
    })
}else {
    index <- which(data$Name == opt$ir)
    data <- data %>%
    mutate_at(vars(- c("Raw_Metabolite")), function(x){
        x / x[index]
    })
}

outData <- data

head(outData)

write.csv(outData, "03_AllMet_Raw_NormArea.csv", row.names = F)



