# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/8/12
library(optparse)
library(magrittr)
library(tidyverse)

option_list <- list(
  make_option("--cc", default = "calculate_config.txt", type = "character", help = "config file"),
  make_option("--si", default = "1;0", type = "character", help = "step and config arg index"),
  make_option("--g", default = "group.txt", type = "character", help = "sample group file")
)
opt <- parse_args(OptionParser(option_list = option_list))

args <- commandArgs(trailingOnly = F)
scriptPath <- dirname(sub("--file=", "", args[grep("--file", args)]))
source(str_c(scriptPath, "/base.R"))

calculateConfigData <- read_tsv(opt$cc, col_names = F, col_types = "cc") %>%
  set_colnames(c("arg", "value"))
calculateConfigData

accordKinds <- configGet(calculateConfigData, "accordKinds") %>%
  str_split(";") %>%
  unlist()
calculateMethods <- configGet(calculateConfigData, "calculateMethods") %>%
  str_split(";") %>%
  unlist()
keepMethods <- configGet(calculateConfigData, "keepMethods") %>%
  str_split(";") %>%
  unlist()
constants <- configGet(calculateConfigData, "constants") %>%
  str_split(";") %>%
  unlist()
topNs <- configGet(calculateConfigData, "topNs") %>%
  str_split(";") %>%
  unlist()
topPercents <- configGet(calculateConfigData, "topPercents") %>%
  str_split(";") %>%
  unlist()

si <- opt$si %>%
  str_split(";") %>%
  unlist()
step <- si[1] %>%
  as.numeric()
index <- si[2] %>%
  as.numeric()

accordKind <- accordKinds[index + 1]
calculateMethod <- calculateMethods[index + 1]
keepMethod <- keepMethods[index + 1]
constant <- constants[index + 1] %>%
  as.numeric()
topN <- topNs[index + 1] %>%
  as.numeric()
topPercent <- topPercents[index + 1] %>%
  as.numeric()

data <- read_tsv(str_c(step - 1, ".result.txt")) %>%
  rename(Metabolite = 1)

selectData <- if (accordKind == "qc") {
  data %>%
    select_at(vars(starts_with("QC"), "Metabolite"))
}else if (accordKind == "noQc") {
  data %>%
    select_at(vars(!starts_with("QC")))
}else {
  data
}

indData <- selectData %>%
  rowwise() %>%
  do({
    result <- as_tibble(.)
    data <- result %>%
      select(-c("Metabolite")) %>%
      unlist()
    result$ind <- if (calculateMethod == "median") {
      median(data)
    }else {
      mean(data)
    }
    result
  }) %>%
  ungroup()

rowNames <- if (keepMethod == "more") {
  indData %>%
    filter(ind > constant) %>%
    .$Metabolite
}else if (keepMethod == "top") {
  indData %>%
    arrange(desc(ind)) %>%
    slice(1:topN) %>%
    .$Metabolite
}else {
  curTopN <- max(1, (nrow(data) * topPercent) / 100)
  indData %>%
    arrange(desc(ind)) %>%
    slice(1:curTopN) %>%
    .$Metabolite
}

outData <- data %>%
  filter(Metabolite %in% rowNames)

outData

write_tsv(outData, str_c(step, ".result.txt"))
write_csv(outData, str_c(step, ".level_filter_var.csv"))








