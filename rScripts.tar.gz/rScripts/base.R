# Title     : TODO
# Objective : TODO
# Created by: yz
# Created on: 11/9/2020

library(ggrepel)
library(Rgraphviz)
library(KEGGgraph)
library(data.table)
library(igraph)
library(RJSONIO)
library(VennDiagram)
library(plotrix)
library(Cairo)
library(jsonlite)

flower_plot <- function(sample, otu_num, core_otu, start, a, b, r, ellipse_col, circle_col) {
  par(bty = 'n', ann = F, xaxt = 'n', yaxt = 'n', mar = c(1, 1, 1, 1))
  plot(c(0, 10), c(0, 10), type = 'n')
  n <- length(sample)
  deg <- 360 / n
  res <- lapply(1:n, function(t) {
    draw.ellipse(x = 5 + cos((start + deg * (t - 1)) * pi / 180),
                 y = 5 + sin((start + deg * (t - 1)) * pi / 180),
                 col = ellipse_col[t],
                 border = ellipse_col[t],
                 a = a, b = b, angle = deg * (t - 1))
    text(x = 5 + 2.5 * cos((start + deg * (t - 1)) * pi / 180),
         y = 5 + 2.5 * sin((start + deg * (t - 1)) * pi / 180),
         otu_num[t])

    if (deg * (t - 1) < 180 && deg * (t - 1) > 0) {
      text(x = 5 + 3.3 * cos((start + deg * (t - 1)) * pi / 180),
           y = 5 + 3.3 * sin((start + deg * (t - 1)) * pi / 180),
           sample[t],
           srt = deg * (t - 1) - start,
           adj = 1,
           cex = 1
      )
    } else {
      text(x = 5 + 3.3 * cos((start + deg * (t - 1)) * pi / 180),
           y = 5 + 3.3 * sin((start + deg * (t - 1)) * pi / 180),
           sample[t],
           srt = deg * (t - 1) + start,
           adj = 0,
           cex = 1
      )
    }
  })
  draw.circle(x = 5, y = 5, r = r, col = circle_col, border = NA)
  text(x = 5, y = 5, paste('Core:', core_otu))
}

vennPlot <- function(datas, labels, colors, baseFamily) {
  labelsStr <- labels %>%
    map_chr(~str_c(.x, "\n"))
  margin <- 0.1
  if (size == 1) {
    data1 <- datas[1] %>%
      unlist()
    area = length(data1)
    tryCatch(draw.single.venn(area = area, fill = colors,
                              category = labelsStr, cat.default.pos = "text",
                              cat.cex = 2, cex = 2, lty = "blank", alpha = 0.5, fontfamily = baseFamily,
                              cat.fontfamily = baseFamily
    ), error = function(e) {
      deleteAndExit(pdfFileName)
    })
  }else if (size == 2) {
    data1 <- datas[1] %>%
      unlist()
    data2 <- datas[2] %>%
      unlist()
    area1 = length(data1)
    area2 = length(data2)
    crossArea = length(intersect(data1, data2))
    tryCatch(draw.pairwise.venn(area1 = area1, area2 = area2, cross.area = crossArea, fill = colors,
                                category = labelsStr, cat.default.pos = "text",
                                cat.cex = 2, cex = c(2, 2, 2), lty = rep("blank", 2), alpha = c(0.5, 0.5),
                                margin = margin,fontfamily = baseFamily, cat.fontfamily = baseFamily
    ), error = function(e) {
      deleteAndExit(pdfFileName)
    })
  }else if (size == 3) {
    data1 <- datas[1] %>%
      unlist()
    data2 <- datas[2] %>%
      unlist()
    data3 <- datas[3] %>%
      unlist()
    area1 <- length(data1)
    area2 <- length(data2)
    area3 <- length(data3)
    n12 <- length(intersect(data1, data2))
    n23 <- length(intersect(data2, data3))
    n13 <- length(intersect(data1, data3))
    n123 <- length(Reduce(intersect, list(data1, data2, data3)))
    draw.triple.venn(area1 = area1, area2 = area2, area3 = area3, n12 = n12, n23 = n23, n13 = n13, n123 = n123,
                     cross.area = crossArea, fill = colors,
                     category = labelsStr, cat.default.pos = "text",
                     cat.cex = 2, cex = 2, lty = rep("blank", 3), alpha = 0.5, margin = margin,fontfamily = baseFamily,
                     cat.fontfamily = baseFamily
    )
  }else if (size == 4) {
    data1 <- datas[1] %>%
      unlist()
    data2 <- datas[2] %>%
      unlist()
    data3 <- datas[3] %>%
      unlist()
    data4 <- datas[4] %>%
      unlist()
    area1 <- length(data1)
    area2 <- length(data2)
    area3 <- length(data3)
    area4 <- length(data4)
    n12 <- length(intersect(data1, data2))
    n13 <- length(intersect(data1, data3))
    n14 <- length(intersect(data1, data4))
    n23 <- length(intersect(data2, data3))
    n24 <- length(intersect(data2, data4))
    n34 <- length(intersect(data3, data4))
    n123 <- length(Reduce(intersect, list(data1, data2, data3)))
    n124 <- length(Reduce(intersect, list(data1, data2, data4)))
    n134 <- length(Reduce(intersect, list(data1, data3, data4)))
    n234 <- length(Reduce(intersect, list(data2, data3, data4)))
    n1234 <- length(Reduce(intersect, list(data1, data2, data3, data4)))
    fill <- colors
    draw.quad.venn(area1 = area1, area2 = area2, area3 = area3, area4 = area4, n12 = n12, n13 = n13, n14 = n14, n23 = n23,
                   n24 = n24, n34 = n34, n123 = n123, n124 = n124, n134 = n134, n234 = n234, n1234 = n1234,
                   category = labelsStr, cat.default.pos = "text",
                   cat.cex = 2, cex = 2, lty = "blank", alpha = 0.5, fill = fill, margin = margin,
                   fontfamily = baseFamily, cat.fontfamily = baseFamily
    )
  }else if (size == 5) {
    data1 <- datas[1] %>%
      unlist()
    data2 <- datas[2] %>%
      unlist()
    data3 <- datas[3] %>%
      unlist()
    data4 <- datas[4] %>%
      unlist()
    data5 <- datas[5] %>%
      unlist()
    area1 <- length(data1)
    area2 <- length(data2)
    area3 <- length(data3)
    area4 <- length(data4)
    area5 <- length(data5)
    n12 <- length(intersect(data1, data2))
    n13 <- length(intersect(data1, data3))
    n14 <- length(intersect(data1, data4))
    n15 <- length(intersect(data1, data5))
    n23 <- length(intersect(data2, data3))
    n24 <- length(intersect(data2, data4))
    n25 <- length(intersect(data2, data5))
    n34 <- length(intersect(data3, data4))
    n35 <- length(intersect(data3, data5))
    n45 <- length(intersect(data4, data5))
    n123 <- length(Reduce(intersect, list(data1, data2, data3)))
    n124 <- length(Reduce(intersect, list(data1, data2, data4)))
    n125 <- length(Reduce(intersect, list(data1, data2, data5)))
    n134 <- length(Reduce(intersect, list(data1, data3, data4)))
    n135 <- length(Reduce(intersect, list(data1, data3, data5)))
    n145 <- length(Reduce(intersect, list(data1, data4, data5)))
    n234 <- length(Reduce(intersect, list(data2, data3, data4)))
    n235 <- length(Reduce(intersect, list(data2, data3, data5)))
    n245 <- length(Reduce(intersect, list(data2, data4, data5)))
    n345 <- length(Reduce(intersect, list(data3, data4, data5)))
    n1234 <- length(Reduce(intersect, list(data1, data2, data3, data4)))
    n1235 <- length(Reduce(intersect, list(data1, data2, data3, data5)))
    n1245 <- length(Reduce(intersect, list(data1, data2, data4, data5)))
    n1345 <- length(Reduce(intersect, list(data1, data3, data4, data5)))
    n2345 <- length(Reduce(intersect, list(data2, data3, data4, data5)))
    n12345 <- length(Reduce(intersect, list(data1, data2, data3, data4, data5)))
    fill <- colors
    draw.quintuple.venn(area1 = area1, area2 = area2, area3 = area3, area4 = area4, area5 = area5, n12 = n12, n13 = n13,
                        n14 = n14,
                        n15 = n15, n23 = n23, n24 = n24, n25 = n25, n34 = n34, n35 = n35, n45 = n45, n123 = n123, n124 = n124, n125 = n125,
                        n134 = n134, n135 = n135, n145 = n145, n234 = n234, n235 = n235, n245 = n245, n345 = n345, n1234 = n1234,
                        n1235 = n1235, n1245 = n1245, n1345 = n1345, n2345 = n2345, n12345 = n12345,
                        category = labelsStr, cat.default.pos = "text",
                        cat.cex = 2, cex = 2, lty = "blank", alpha = 0.5, fill = fill, margin = margin,
                        fontfamily = baseFamily, cat.fontfamily = baseFamily
    )
  }else if (size > 5) {
    plotData <- read_csv("Venn_Data.csv")
    columnName <- str_c(labels, collapse = " & ")
    core_num <- plotData %>%
      select(columnName) %>%
      filter_all(any_vars(!is.na(.))) %>%
      nrow()

    otu_num <- labels %>%
      map_dbl(function(name) {
        newName <- str_c(name)
        plotData %>%
          select(newName) %>%
          filter_all(any_vars(!is.na(.))) %>%
          nrow()
      })
    fill <- colors
    flower_plot(labels, otu_num, core_num, start = 90, a = 0.5, b = 2, r = 1, ellipse_col = fill, circle_col = 'white')
  }else {
    deleteAndExit(pdfFileName)
  }
}

getFileNameWithPrefix <- function(fileName, prefix) {
  if (str_length(prefix) == 0) {
    fileName
  }else str_c(prefix, "_", fileName)
}

zd_pcor <- function(left = left, right = right, confounding = confounding, unique_id_colname = "ID", mannual_n_for_fdr = F, filtered_pairs_saved_in = "global_filtered_pairs",
                    method = "spearman"
) {
  if (exists(filtered_pairs_saved_in) == F) {
    global_filtered_pairs <<- data.frame()
    cat("初始化了相应的变量,将剔除掉的变量对子保存在了 global_filtered_pairs 变量中. 这个名字是固定写死的,不要更改.")
  }

  part_1 <- left[, unique_id_colname] %>% as.character()
  part_2 <- right[, unique_id_colname] %>% as.character()
  part_3 <- confounding[, unique_id_colname] %>% as.character()

  pooled_ID <- c(part_1, part_2, part_3) %>% unique()

  neworder <- pooled_ID %>% order()
  pooled_ID <- pooled_ID[neworder] %>% data.frame(., stringsAsFactors = F)
  colnames(pooled_ID) <- unique_id_colname

  left <- merge(pooled_ID, left, by = c(unique_id_colname), all.x = T)
  right <- merge(pooled_ID, right, by = c(unique_id_colname), all.x = T)
  confounding <- merge(pooled_ID, confounding, by = c(unique_id_colname), all.x = T)

  left <- left[, -1]
  right <- right[, -1]
  confounding <- confounding[, -1]

  for (i in 1:ncol(left)) {
    if (i == 1) { pooled_r_and_p <- data.frame()
      pooled_error <- data.frame()
    }
    for (j in 1:ncol(right)) {
      pair_1 <- colnames(left)[i]
      pair_2 <- colnames(right)[j]

      temp_frame <- cbind(left[, i], right[, j], confounding)
      temp_frame <- na.omit(temp_frame)
      temp_frame <- apply(temp_frame, 2, function(each_col) {
        result <- each_col %>% as.character() %>% as.numeric()
      })
      IS_error <<- F
      if (T) {
        tryCatch(each_line <- pcor.test(x = temp_frame[, 1], y = temp_frame[, 2],
                                        z = temp_frame[, 3:ncol(temp_frame)], method = c(method)),
                 error = function(e) {
                   IS_error <<- T
                   # cat (i , ' ', pair_1 , j, ' ', pair_2 , "的偏相关系数无法被计算\n")

                   each_filtered_pair <- data.frame(pair_1 = pair_1, pair_2 = pair_2)
                   global_filtered_pairs <<- rbind(global_filtered_pairs, each_filtered_pair)
                 })
      }

      if (IS_error == F) {
        each_line <- data.frame(pair_1 = pair_1, pair_2 = pair_2, each_line, stringsAsFactors = F)
        colnames(each_line) <- c("pair_1", "pair_2", "r", "p", "statistic", "n", "gp", "Method")
        pooled_r_and_p <- rbind(pooled_r_and_p, each_line)
      }
    }
  }

  IS_filtered <- is.na(pooled_r_and_p[, "p"]) == T
  temp_filtered_data <- pooled_r_and_p[IS_filtered, c("pair_1", "pair_2")]
  global_filtered_pairs <<- rbind(global_filtered_pairs, temp_filtered_data)
  pooled_r_and_p <- pooled_r_and_p[!IS_filtered,]

  if (mannual_n_for_fdr > 0) { n <- mannual_n_for_fdr } else {
    n <- nrow(pooled_r_and_p) }
  return(pooled_r_and_p)
}

isT <- function(data1, data2) {
  var1 <- var(data1)
  if (var1 == 0) {
    return(F)
  }
  d1Test <- shapiro.test(data1)
  d1P <- d1Test$p.value
  if (d1P < 0.05) {
    return(F)
  }
  var2 <- var(data2)
  if (var2 == 0) {
    return(F)
  }
  d2Test <- shapiro.test(data2)
  d2P <- d2Test$p.value
  if (d2P < 0.05) {
    return(F)
  }
  data <- tibble(value = c(data1, data2), group = factor(c(rep(1, length(data1)), rep(2, length(data2)))))
  bTest <- bartlett.test(value ~ group, data)
  bp <- bTest$p.value
  if (bp < 0.05) {
    return(F)
  }
  return(T)
}

my.fc <- function(data1, data2, method) {
  fc <- 0
  curMethod <- method
  if (curMethod == "auto") {
    b <- isT(data1, data2)
    if (b) {
      curMethod <- "mean"
    }else {
      curMethod <- "median"
    }
  }

  if (curMethod == "median") {
    median1 <- median(data1)
    median2 <- median(data2)
    fc <- median2 / median1
  }else if (curMethod == "mean") {
    mean1 <- mean(data1)
    mean2 <- mean(data2)
    fc <- mean2 / mean1
  }
  if (is.nan(fc)) {
    fc <- 1
  }
  list(fc = fc, method = curMethod)
}

my.test <- function(data1, data2, paired, method) {
  p <- 0
  curMethod <- method
  if (curMethod == "auto") {
    b <- isT(data1, data2)
    if (b) {
      curMethod <- "t"
    }else {
      curMethod <- "u"
    }
  }

  if (curMethod == "u") {
    test <- wilcox.test(data1, data2, paired = paired)
    p <- test$p.value
    curMethod <- "wilcox.test"
  }else if (curMethod == "t") {
    tryCatch({
      test <- t.test(data1, data2, paired = paired)
      p <- test$p.value
    }, error = function(e) {
      p <- 1
    })

    curMethod <- "t.test"
  }
  if (is.na(p)) {
    p <- 1
  }
  list(p = p, method = curMethod)
}

plsda.my.test <- function(formula, data, method, paired) {
  p <- 1
  if (method == "wilcox.test") {
    test <- wilcox.test(formula = formula, data = data, paired = paired)
    p <- test$p.value
  }else {
    test <- kruskal.test(formula = formula, data = data)
    p <- test$p.value
  }
  list(p = p)
}

configGet <- function(configData, key) {
  configData %>%
    filter(arg == key) %>%
    .$value
}

.on.public.web <- F

.set.mSet <- function(mSetObj = NA) {
  if (.on.public.web) {
    mSet <<- mSetObj;
    return(1);
  }
  return(mSetObj);
}

.get.mSet <- function(mSetObj = NA) {
  if (.on.public.web) {
    return(mSet)
  }else {
    return(mSetObj);
  }
}

Setup.MapData <- function(mSetObj = NA, qvec)
{
  mSetObj <- .get.mSet(mSetObj)
  mSetObj$dataSet$cmpd <- qvec
  return(.set.mSet(mSetObj))
}

.read.metaboanalyst.lib <- function(filenm, dataDir) {
  lib.path <- paste(dataDir, "/", filenm, sep = "");
  return(readRDS(lib.path));
}

MetaboliteMappingExact <- function(mSetObj = NA, q.type, dataDir)
{
  mSetObj <- .get.mSet(mSetObj)
  qvec <- mSetObj$dataSet$cmpd
  hit.inx <- vector(mode = "numeric", length = length(qvec))
  names(hit.inx) <- qvec
  match.values <- vector(mode = "character", length = length(qvec))
  match.state <- vector(mode = "numeric", length = length(qvec))
  cmpd.db <- .read.metaboanalyst.lib("compound_db.rds", dataDir = dataDir)
  if (q.type == "hmdb") {
    n <- 5
    hmdb.digits <- as.vector(sapply(cmpd.db$hmdb, function(x) strsplit(x,
                                                                       "HMDB")[[1]][2]))
    hmdb.v3.ids <- paste0("HMDB", substr(hmdb.digits, nchar(hmdb.digits) -
      n + 1, nchar(hmdb.digits)))
    hit.inx.v3 <- match(tolower(qvec), tolower(hmdb.v3.ids))
    hit.inx <- match(tolower(qvec), tolower(cmpd.db$hmdb))
    hit.inx[is.na(hit.inx)] <- hit.inx.v3[is.na(hit.inx)]
    match.values <- cmpd.db$name[hit.inx]
    match.state[!is.na(hit.inx)] <- 1
  }
  else if (q.type == "pubchem") {
    hit.inx <- match(tolower(qvec), tolower(cmpd.db$pubchem))
    match.values <- cmpd.db$name[hit.inx]
    match.state[!is.na(hit.inx)] <- 1
  }
  else if (q.type == "chebi") {
    hit.inx <- match(tolower(qvec), tolower(cmpd.db$chebi))
    match.values <- cmpd.db$name[hit.inx]
    match.state[!is.na(hit.inx)] <- 1
  }
  else if (q.type == "metlin") {
    hit.inx <- match(tolower(qvec), tolower(cmpd.db$metlin))
    match.values <- cmpd.db$name[hit.inx]
    match.state[!is.na(hit.inx)] <- 1
  }
  else if (q.type == "kegg") {
    hit.inx <- match(tolower(qvec), tolower(cmpd.db$kegg))
    match.values <- cmpd.db$name[hit.inx]
    match.state[!is.na(hit.inx)] <- 1
  }
  else if (q.type == "Metabolite") {
    hit.inx <- match(tolower(qvec), tolower(cmpd.db$name))
    match.values <- cmpd.db$name[hit.inx]
    match.state[!is.na(hit.inx)] <- 1
    syn.db <- .read.metaboanalyst.lib("syn_nms.rds", dataDir = dataDir)
    syns.list <- syn.db$syns.list
    todo.inx <- which(is.na(hit.inx))
    if (length(todo.inx) > 0) {
      for (i in 1:length(syns.list)) {
        syns <- syns.list[[i]]
        hitInx <- match(tolower(qvec[todo.inx]), tolower(syns))
        hitPos <- which(!is.na(hitInx))
        if (length(hitPos) > 0) {
          orig.inx <- todo.inx[hitPos]
          hit.inx[orig.inx] <- i
          match.values[orig.inx] <- cmpd.db$name[i]
          match.state[orig.inx] <- 1
          todo.inx <- todo.inx[is.na(hitInx)]
        }
        if (length(todo.inx) == 0)
          break
      }
    }
  }
  else {
    print(paste("Unknown compound ID type:", q.type))
    hit.inx <- match(tolower(qvec), tolower(cmpd.db$hmdb))
    hit.inx2 <- match(tolower(qvec), tolower(cmpd.db$kegg))
    nohmdbInx <- is.na(hit.inx)
    hit.inx[nohmdbInx] <- hit.inx2[nohmdbInx]
    match.values <- cmpd.db$name[hit.inx]
    match.state[!is.na(hit.inx)] <- 1
  }
  gc()
  mSetObj$name.map$query.vec <- qvec
  mSetObj$name.map$hit.inx <- hit.inx
  mSetObj$name.map$hit.values <- match.values
  mSetObj$name.map$match.state <- match.state
  return(.set.mSet(mSetObj))
}

CrossReferencing <- function(mSetObj = NA, q.type, hmdb = T, pubchem = T, chebi = F,
                             kegg = T, metlin = F, dataDir)
{
  mSetObj <- .get.mSet(mSetObj)
  mSetObj$return.cols <- c(hmdb, pubchem, chebi, kegg, metlin)
  if (!exists("name.map", where = mSetObj)) {
    mSetObj$name.map <- list()
  }
  mSetObj$dataSet$q.type <- q.type
  if (.on.public.web) {
    .set.mSet(mSetObj)
    MetaboliteMappingExact(mSetObj, q.type, dataDir = dataDir)
    mSetObj <- .get.mSet(mSetObj)
  }
  else {
    mSetObj <- MetaboliteMappingExact(mSetObj, q.type, dataDir = dataDir)
  }
  todo.inx <- which(is.na(mSetObj$name.map$hit.inx))
  if (length(todo.inx) / length(mSetObj$name.map$hit.inx) > 0.5) {
    mSetObj$msgSet$nmcheck.msg <- c(0, "Over half of the compound IDs could not be matched to our database. Please make \n                                    sure that correct compound IDs or common compound names are used.")
  }
  else if (length(todo.inx) > 15) {
    mSetObj$msgSet$nmcheck.msg <- c(2, "There are >15 compounds without matches. You can either proceed or if necessary, update these compound IDs and upload again.")
  }
  else {
    mSetObj$msgSet$nmcheck.msg <- c(1, "Name matching OK, please inspect (and manual correct) the results then proceed.")
  }
  return(.set.mSet(mSetObj))
}

InitDataObjects <- function(data.type, anal.type, paired = FALSE)
{
  dataSet <- list()
  dataSet$type <- data.type
  dataSet$design.type <- "regular"
  dataSet$cls.type <- "disc"
  dataSet$format <- "rowu"
  dataSet$paired <- paired
  analSet <- list()
  analSet$type <- anal.type
  mSetObj <- list()
  mSetObj$dataSet <- dataSet
  mSetObj$analSet <- analSet
  mSetObj$imgSet <- list()
  mSetObj$msgSet <- list()
  mSetObj$msgSet$msg.vec <- vector(mode = "character")
  mSetObj$cmdSet <- vector(mode = "character")
  msg.vec <<- ""
  module.count <<- 0
  smpdbpw.count <<- 0
  data.org <<- NULL
  if (.on.public.web) {
    lib.path <<- "../../data/"
    library(BiocParallel)
    register(SerialParam())
  }
  else {
    lib.path <<- "https://www.metaboanalyst.ca/resources/data/"
  }
  peakFormat <<- "mpt"
  mdata.all <<- list()
  mdata.siggenes <<- vector("list")
  meta.selected <<- TRUE
  anal.type <<- anal.type
  Cairo::CairoFonts(regular = "Arial:style=Regular", bold = "Arial:style=Bold",
                    italic = "Arial:style=Italic", bolditalic = "Arial:style=Bold Italic",
                    symbol = "Symbol")
  print("MetaboAnalyst R objects initialized ...")
  return(.set.mSet(mSetObj))
}

CreateMappingResultTable <- function(mSetObj = NA, dataDir)
{
  mSetObj <- .get.mSet(mSetObj)
  qvec <- mSetObj$dataSet$cmpd
  if (is.null(qvec)) {
    return()
  }
  pre.style <- NULL
  post.style <- NULL
  if (mSetObj$dataSet$q.type == "Metabolite") {
    no.prestyle <- "<strong style=\"background-color:yellow; font-size=125%; color=\"black\">"
    no.poststyle <- "</strong>"
  }
  else {
    no.prestyle <- "<strong style=\"background-color:red; font-size=125%; color=\"black\">"
    no.poststyle <- "</strong>"
  }
  hit.inx <- mSetObj$name.map$hit.inx
  hit.values <- mSetObj$name.map$hit.values
  match.state <- mSetObj$name.map$match.state
  html.res <- matrix("", nrow = length(qvec), ncol = 8)
  csv.res <- matrix("", nrow = length(qvec), ncol = 9)
  colnames(csv.res) <- c("Query", "Match", "HMDB", "PubChem",
                         "ChEBI", "KEGG", "METLIN", "SMILES", "Comment")
  cmpd.db <- .read.metaboanalyst.lib("compound_db.rds", dataDir = dataDir)
  for (i in 1:length(qvec)) {
    if (match.state[i] == 1) {
      pre.style <- ""
      post.style = ""
    }
    else {
      pre.style <- no.prestyle
      post.style <- no.poststyle
    }
    hit <- cmpd.db[hit.inx[i], , drop = F]
    html.res[i,] <- c(paste(pre.style, qvec[i], post.style,
                            sep = ""), paste(ifelse(match.state[i] == 0, "",
                                                    hit.values[i]), sep = ""), paste(ifelse(match.state[i] ==
                                                                                              0 ||
                                                                                              is.na(hit$hmdb_id) ||
                                                                                              hit$hmdb_id == "" ||
                                                                                              hit$hmdb_id ==
                                                                                                "NA", "-", paste("<a href=http://www.hmdb.ca/metabolites/",
                                                                                                                 hit$hmdb_id, " target='_blank'>", hit$hmdb_id, "</a>",
                                                                                                                 sep = "")), sep = ""), paste(ifelse(match.state[i] ==
                                                                                                                                                       0 ||
                                                                                                                                                       is.na(hit$pubchem_id) ||
                                                                                                                                                       hit$pubchem_id == "" ||
                                                                                                                                                       hit$pubchem_id == "NA", "-", paste("<a href=http://pubchem.ncbi.nlm.nih.gov/summary/summary.cgi?cid=",
                                                                                                                                                                                          hit$pubchem_id, " target='_blank'>", hit$pubchem_id,
                                                                                                                                                                                          "</a>", sep = "")), sep = ""), paste(ifelse(match.state[i] ==
                                                                                                                                                                                                                                        0 ||
                                                                                                                                                                                                                                        is.na(hit$chebi_id) ||
                                                                                                                                                                                                                                        hit$chebi_id == "" ||
                                                                                                                                                                                                                                        hit$chebi_id == "NA", "-", paste("<a href=http://www.ebi.ac.uk/chebi/searchId.do?chebiId=",
                                                                                                                                                                                                                                                                         hit$chebi_id, " target='_blank'>", hit$chebi_id,
                                                                                                                                                                                                                                                                         "</a>", sep = "")), sep = ""), paste(ifelse(match.state[i] ==
                                                                                                                                                                                                                                                                                                                       0 ||
                                                                                                                                                                                                                                                                                                                       is.na(hit$kegg_id) ||
                                                                                                                                                                                                                                                                                                                       hit$kegg_id == "" ||
                                                                                                                                                                                                                                                                                                                       hit$kegg_id ==
                                                                                                                                                                                                                                                                                                                         "NA", "-", paste("<a href=http://www.genome.jp/dbget-bin/www_bget?",
                                                                                                                                                                                                                                                                                                                                          hit$kegg_id, " target='_blank'>", hit$kegg_id, "</a>",
                                                                                                                                                                                                                                                                                                                                          sep = "")), sep = ""), paste(ifelse(match.state[i] ==
                                                                                                                                                                                                                                                                                                                                                                                0 ||
                                                                                                                                                                                                                                                                                                                                                                                is.na(hit$metlin_id) ||
                                                                                                                                                                                                                                                                                                                                                                                hit$metlin_id == "" ||
                                                                                                                                                                                                                                                                                                                                                                                hit$metlin_id == "NA", "-", paste("<a href=http://metlin.scripps.edu/metabo_info.php?molid=",
                                                                                                                                                                                                                                                                                                                                                                                                                  hit$metlin_id, " target='_blank'>", hit$metlin_id,
                                                                                                                                                                                                                                                                                                                                                                                                                  "</a>", sep = "")), sep = ""), ifelse(match.state[i] !=
                                                                                                                                                                                                                                                                                                                                                                                                                                                          1, "View", ""))
    csv.res[i,] <- c(qvec[i], ifelse(match.state[i] == 0,
                                     "NA", hit.values[i]), ifelse(match.state[i] == 0,
                                                                  "NA", hit$hmdb_id), ifelse(match.state[i] == 0, "NA",
                                                                                             hit$pubchem_id), ifelse(match.state[i] == 0, "NA",
                                                                                                                     hit$chebi_id), ifelse(match.state[i] == 0, "NA",
                                                                                                                                           hit$kegg_id), ifelse(match.state[i] == 0, "NA", hit$metlin_id),
                     ifelse(match.state[i] == 0, "NA", ""), match.state[i])
  }
  return.cols <- c(TRUE, TRUE, mSetObj$return.cols, TRUE)
  html.res <- html.res[, return.cols, drop = F]
  csv.res <- csv.res[, return.cols, drop = F]

  mSetObj$dataSet$map.table <- csv.res
  resData <- csv.res %>%
    as.data.frame(stringsAsFactors = F) %>%
    select(-c("SMILES"))
  write_tsv(resData, "name_map.txt")
  if (.on.public.web) {
    .set.mSet(mSetObj)
    return(as.vector(html.res))
  }
  else {
    return(.set.mSet(mSetObj))
  }
}

.load.metaboanalyst.lib <- function(libtype, libname, dataDir) {
  destfile <- paste(libname, ".rda", sep = "");
  destfile <- paste(dataDir, "/", libtype, "/", libname, ".rda", sep = "");
  load(destfile, .GlobalEnv);
}

SetKEGG.PathLib <- function(mSetObj = NA, kegg.rda, dataDir)
{
  mSetObj <- .get.mSet(mSetObj)
  mSetObj$msgSet$lib.msg <- paste("Your selected pathway library code is \\textbf{",
                                  kegg.rda, "}(KEGG organisms abbreviation).")
  kegglib <- .load.metaboanalyst.lib("kegg", kegg.rda, dataDir = dataDir)
  mSetObj$pathwaylibtype <- "KEGG"
  if (.on.public.web) {
    .set.mSet(mSetObj)
    return(1)
  }
  return(.set.mSet(mSetObj))
}

SetMetabolomeFilter <- function(mSetObj = NA, TorF)
{
  mSetObj <- .get.mSet(mSetObj)
  mSetObj$dataSet$use.metabo.filter <- TorF
  return(.set.mSet(mSetObj))
}

GetFinalNameMap <- function(mSetObj = NA, dataDir)
{
  mSetObj <- .get.mSet(mSetObj)
  hit.inx <- mSetObj$name.map$hit.inx
  hit.values <- mSetObj$name.map$hit.values
  match.state <- mSetObj$name.map$match.state
  qvec <- mSetObj$dataSet$cmpd
  nm.mat <- matrix(nrow = length(qvec), ncol = 4)
  colnames(nm.mat) <- c("query", "hmdb", "kegg", "hmdbid")
  cmpd.db <- .read.metaboanalyst.lib("compound_db.rds", dataDir = dataDir)
  for (i in 1:length(qvec)) {
    hit <- cmpd.db[hit.inx[i], , drop = F]
    if (match.state[i] == 0) {
      hmdb.hit <- NA
      hmdb.hit.id <- NA
      kegg.hit <- NA
    }
    else {
      hmdb.hit <- ifelse(nchar(hit.values[i]) == 0, NA,
                         hit.values[i])
      hmdb.hit.id <- ifelse(nchar(hit$hmdb_id) == 0, NA,
                            hit$hmdb_id)
      kegg.hit <- ifelse(nchar(hit$kegg_id) == 0, NA, hit$kegg_id)
    }
    nm.mat[i,] <- c(qvec[i], hmdb.hit, kegg.hit, hmdb.hit.id)
  }
  return(as.data.frame(nm.mat))
}

GetORA.pathNames <- function(mSetObj = NA)
{
  mSetObj <- .get.mSet(mSetObj)
  hit.inx <- match(rownames(mSetObj$analSet$ora.mat), metpa$path.ids)
  return(names(metpa$path.ids)[hit.inx])
}

SetupKEGGLinks <- function(smpdb.ids)
{
  kegg.vec <- metpa$path.keggs[match(smpdb.ids, names(metpa$mset.list))]
  GetKEGGLinks(kegg.vec)
}

GetKEGGLinks <- function(kegg.vec)
{
  lk.len <- length(kegg.vec)
  all.lks <- vector(mode = "character", length = lk.len)
  for (i in 1:lk.len) {
    lks <- strsplit(kegg.vec[i], "; ")[[1]]
    if (!is.na(lks[1])) {
      all.lks[i] <- paste("http://www.genome.jp/kegg-bin/show_pathway?",
                          lks, sep = "")
    }
  }
  return(all.lks)
}

SetupSMPDBLinks <- function(kegg.ids)
{
  smpdb.vec <- names(metpa$path.smps)[match(kegg.ids, metpa$path.smps)]
  GetSMPDBLinks(smpdb.vec)
}

GetSMPDBLinks <- function(smpdb.vec)
{
  lk.len <- length(smpdb.vec)
  all.lks <- vector(mode = "character", length = lk.len)
  for (i in 1:lk.len) {
    lks <- strsplit(smpdb.vec[i], "; ")[[1]]
    if (!is.na(lks[1])) {
      all.lks[i] <- paste("http://www.smpdb.ca/view/",
                          lks, sep = "", collapse = " ")
    }
  }
  return(all.lks)
}

AddErrMsg <- function(msg)
{
  msg.vec <<- ""
  msg.vec <<- c(msg.vec, msg)
  print(msg)
}

GetFisherPvalue <- function(numSigMembers, numSigAll, numMembers, numAllMembers)
{
  z <- cbind(numSigMembers, numSigAll - numSigMembers, numMembers -
    numSigMembers, numAllMembers - numMembers - numSigAll +
               numSigMembers)
  z <- lapply(split(z, 1:nrow(z)), matrix, ncol = 2)
  z <- lapply(z, fisher.test, alternative = "greater")
  p.values <- as.numeric(unlist(lapply(z, "[[", "p.value"),
                                use.names = FALSE))
  return(p.values)
}

CalculateOraScore <- function(mSetObj = NA, nodeImp, method, dataDir, fcData, hasSmp, diffData)
{
  mSetObj <- .get.mSet(mSetObj)
  nm.map <- GetFinalNameMap(mSetObj, dataDir = dataDir)
  nmMap <- nm.map %>%
    as.data.frame()
  if (mSetObj$pathwaylibtype == "KEGG") {
    valid.inx <- !(is.na(nm.map$kegg) | duplicated(nm.map$kegg))
    ora.vec <- nm.map$kegg[valid.inx]
  }
  else if (mSetObj$pathwaylibtype == "SMPDB") {
    valid.inx <- !(is.na(nm.map$hmdbid) | duplicated(nm.map$hmdbid))
    ora.vec <- nm.map$hmdbid[valid.inx]
  }
  q.size <- length(ora.vec)
  if (is.na(ora.vec) || q.size == 0) {
    if (mSetObj$pathwaylibtype == "KEGG") {
      AddErrMsg("No valid KEGG compounds found!")
    }
    else if (mSetObj$pathwaylibtype == "SMPDB") {
      AddErrMsg("No valid SMPDB compounds found!")
    }
    return(0)
  }
  current.mset <- metpa$mset.list
  uniq.count <- metpa$uniq.count
  if (mSetObj$dataSet$use.metabo.filter && !is.null(mSetObj$dataSet$metabo.filter.kegg)) {
    current.mset <- lapply(current.mset, function(x) {
      x[x %in% mSetObj$dataSet$metabo.filter.kegg]
    })
    mSetObj$analSet$ora.filtered.mset <- current.mset
    uniq.count <- length(unique(unlist(current.mset, use.names = FALSE)))
  }
  hits <- lapply(current.mset, function(x) {
    x[x %in% ora.vec]
  })
  hit.num <- unlist(lapply(hits, function(x) {
    length(x)
  }), use.names = FALSE)
  set.size <- length(current.mset)
  set.num <- unlist(lapply(current.mset, length), use.names = FALSE)
  # res.mat <- matrix(0, nrow = set.size, ncol = 8)
  res.mat <- tibble(name = names(current.mset))
  # rownames(res.mat) <- names(current.mset)
  # colnames(res.mat) <- c("Total_In_Pathway", "Expected", "Hits", "Raw p",
  # "-log(p)", "Holm Adjusted P", "FDR", "Impact")
  # colnames(res.mat) <- c("name","Total_In_Pathway", "Expected", "Hits", "Raw p",
  # "-log(p)", "Holm Adjusted P", "FDR", "Impact")
  if (nodeImp == "rbc") {
    imp.list <- metpa$rbc
    mSetObj$msgSet$topo.msg <- "Your selected node importance measure for topological analysis is \\textbf{relative betweenness centrality}."
  }
  else {
    imp.list <- metpa$dgr
    mSetObj$msgSet$topo.msg <- "Your selected node importance measure for topological analysis is \\textbf{out degree centrality}."
  }
  # res.mat[, 1] <- set.num
  res.mat <- res.mat %>%
    mutate(`Total_In_Pathway` = set.num)
  # res.mat[, 2] <- q.size * (set.num / uniq.count)
  res.mat <- res.mat %>%
    mutate(`Expected` = q.size * (set.num / uniq.count))
  # res.mat[, 3] <- hit.num
  res.mat <- res.mat %>%
    mutate(Hits = hit.num)
  if (method == "fisher") {
    # res.mat[, 4] <- GetFisherPvalue(hit.num, q.size, set.num,
    #                                 uniq.count)
    rawP <- GetFisherPvalue(hit.num, q.size, set.num, uniq.count)
    mSetObj$msgSet$rich.msg <- "The selected over-representation analysis method is \\textbf{Fishers' exact test}."
  }
  else {
    # res.mat[, 4] <- phyper(hit.num - 1, set.num, uniq.count -
    #   set.num, q.size, lower.tail = F)
    rawP <- phyper(hit.num - 1, set.num, uniq.count - set.num, q.size, lower.tail = F)
    mSetObj$msgSet$rich.msg <- "The selected over-representation analysis method is \\textbf{Hypergeometric test}."
  }
  res.mat <- res.mat %>%
    mutate(`Raw p` = rawP)
  # res.mat[, 5] <- -log(res.mat[, 4])
  res.mat <- res.mat %>%
    mutate(`-log(p)` = -log(`Raw p`))
  # res.mat[, 6] <- p.adjust(res.mat[, 4], "holm")
  res.mat <- res.mat %>%
    mutate(`Holm Adjusted P` = p.adjust(`Raw p`, "holm"))
  # res.mat[, 7] <- p.adjust(res.mat[, 4], "fdr")
  res.mat <- res.mat %>%
    mutate(`FDR` = p.adjust(`Raw p`, "fdr"))
  # res.mat[, 8] <- mapply(function(x, y) {
  #   sum(x[y])
  # }, imp.list, hits)
  impact <- mapply(function(x, y) {
    sum(x[y])
  }, imp.list, hits)
  res.mat <- res.mat %>%
    mutate(Impact = impact)
  # res.mat <- res.mat[hit.num > 0, , drop = FALSE]
  res.mat <- res.mat %>%
    filter(Hits > 0)
  # res.mat <- res.mat[!is.na(res.mat[, 8]), , drop = FALSE]
  res.mat <- res.mat %>%
    filter(!is.na(Impact))
  res.mat <- res.mat %>%
    arrange(`Raw p`, Impact)

  # if (nrow(res.mat) > 1) {
  #   ord.inx <- order(res.mat[, 4], res.mat[, 8])
  #   res.mat <- res.mat[ord.inx,]
  # }
  res.mat <- res.mat %>%
    distinct(name, .keep_all = T) %>%
    column_to_rownames("name") %>%
    as.matrix()

  mSetObj$analSet$ora.mat <- signif(res.mat, 5)
  mSetObj$analSet$ora.hits <- hits
  mSetObj$analSet$node.imp <- nodeImp
  .set.mSet(mSetObj)
  save.mat <- mSetObj$analSet$ora.mat
  rownames(save.mat) <- GetORA.pathNames(mSetObj)
  if (mSetObj$pathwaylibtype == "KEGG") {
    hit.inx <- match(rownames(mSetObj$analSet$ora.mat), metpa$path.ids)
    extraKegg <- c()
    redNames <- c()
    setName <- names(metpa$path.ids)[hit.inx]
    for (msetNm in setName) {
      pathid <- metpa$path.ids[msetNm]
      mset <- metpa$mset.list[[pathid]]
      hits <- mSetObj$analSet$ora.hits
      red.inx <- which(mset %in% hits[[pathid]])
      cName = mset[red.inx]
      nms <- names(mset);
      eachRowkeggID <- c()
      for (value in nms[red.inx]) {
        keggId = cName[value]
        eachRowkeggID <- c(eachRowkeggID, keggId)
      }
      eachCol <- fcData %>%
        filter(KEGG %in% eachRowkeggID) %>%
        .$col
      eachRowkegg <- paste("/", eachRowkeggID, "%09", eachCol, collapse = "", sep = "")
      extraKegg <- c(extraKegg, eachRowkegg)
      redName <- paste(sort(nms[red.inx]), collapse = "\n")
      redNames <- c(redNames, redName)
    }
    save.mat <- cbind(save.mat, redNames)
    kegg.vec <- rownames(mSetObj$analSet$ora.mat)
    keggId <- kegg.vec
    keggLink <- paste("http://www.genome.jp/kegg-bin/show_pathway?", kegg.vec, extraKegg, sep = "")

    saveMat <- cbind(save.mat, keggLink)
    save.mat <- saveMat %>%
      as.data.frame(stringsAsFactors = F) %>%
      rownames_to_column("Metabolite")

    if (hasSmp) {
      save.mat <- save.mat %>%
        mutate(keggId = keggId) %>%
        mutate_at(vars("keggId"), function(x) {
          smpdb.vec <- names(metpa$path.smps)[match(x, metpa$path.smps)]
          link <- smpdb.vec %>%
            map_chr(function(smpId) {
              lks <- strsplit(smpId, "; ")[[1]]
              if (!is.na(lks[1])) {
                paste("http://www.smpdb.ca/view/",
                      lks, sep = "", collapse = " ")
              }else ""
            })
          link
        })
    }
  } else if (mSetObj$pathwaylibtype == "SMPDB") {
    hit.inx <- match(rownames(mSetObj$analSet$ora.mat), metpa$path.ids)
    extraKegg <- c()
    redNames <- c()
    setName <- names(metpa$path.ids)[hit.inx]

    hmdbIds <- setName %>%
      map_chr(function(x) {
        pathid <- metpa$path.ids[x]
        mset <- metpa$mset.list[[pathid]]
        red.inx <- which(mset %in% hits[[pathid]])
        ids <- mset[red.inx]
        str_c(ids, collapse = ",")
      })
    hmdbDf <- tibble(Name = setName, hmdbId = hmdbIds)
    write_tsv(hmdbDf, "red_hmdb_id.txt")

    for (msetNm in setName) {
      pathid <- metpa$path.ids[msetNm]
      mset <- metpa$mset.list[[pathid]]
      hits <- mSetObj$analSet$ora.hits
      red.inx <- which(mset %in% hits[[pathid]])
      nms <- names(mset)
      eachRowkeggID <- c()
      for (value in nms[red.inx]) {
        keggId = nmMap %>%
          filter(query == value) %>%
          head(1) %>%
          .$kegg %>%
          as.character()
        eachRowkeggID <- c(eachRowkeggID, keggId) %>%
          discard(is.na)
      }
      eachCol <- fcData %>%
        filter(KEGG %in% eachRowkeggID) %>%
        .$col
      eachRowkegg <- if (length(eachRowkeggID) > 0) {
        eachRowkegg <- paste("/", eachRowkeggID, "%09", eachCol, collapse = "", sep = "")
      } else ""
      extraKegg <- c(extraKegg, eachRowkegg)
      redName <- paste(sort(nms[red.inx]), collapse = "\n")
      redNames <- c(redNames, redName)
    }
    save.mat <- cbind(save.mat, redNames)
    smpdb.ids <- rownames(mSetObj$analSet$ora.mat)
    kegg.vec <- metpa$path.keggs[match(smpdb.ids, names(metpa$mset.list))]
    keggLink <- kegg.vec %>%
      map_chr(function(x) {
        unlist(strsplit(x, ";"))[1]
      }) %>%
      imap_chr(function(v, i) {
        extraKegg <- extraKegg[i]
        if (is.na(v)) {
          ""
        }else {
          paste0("http://www.genome.jp/kegg-bin/show_pathway?", v, extraKegg)
        }
      })
    smpdId <- smpdb.ids
    saveMat <- cbind(save.mat, keggLink, smpdId)
    save.mat <- saveMat %>%
      as.data.frame(stringsAsFactors = F) %>%
      rownames_to_column("Metabolite") %>%
      mutate_at(vars("smpdId"), function(x) {
        GetSMPDBLinks(x)
      })
  }

  print("=log=")

  print(diffData)

  colNames <- if (hasSmp) {
    c("Metabolite", "Total_In_Pathway", "Expected", "Hits", "Raw P", "'-ln(p)", "Holm P", "FDR", "Impact",
      "Enriched_Compounds", "KEGGLink", "SMPLink")
  }else {
    c("Metabolite", "Total_In_Pathway", "Expected", "Hits", "Raw P", "'-ln(p)", "Holm P", "FDR", "Impact",
      "Enriched_Compounds", "KEGGLink")
  }

  save.mat <- if (nrow(save.mat) == 0) {
    save.mat %>%
      set_colnames(colNames) %>%
      rename(` ` = Metabolite)
  } else {
    save.mat %>%
      rowwise() %>%
      do({
        result <- as_tibble(.)
        link <- result$keggLink %>%
          as.character()
        names <- str_split(link, "/") %>%
          unlist() %>%
          keep(~startsWith(.x, "C")) %>%
          map_chr(function(x) {
            cNumber <- str_split(x, "%09") %>% unlist() %>% .[1]
            name <- diffData %>%
              filter(KEGG == cNumber) %>%
              head(1) %>%
              .$Metabolite
            name
          })
        redName <- str_c(names, collapse = "\n")
        df <- result %>%
          mutate(redNames = redName)
        df
      }) %>%
      ungroup() %>%
      set_colnames(colNames) %>%
      rename(` ` = Metabolite)
  }

  write_csv(save.mat, "Pathway_Result.csv")

  if (.on.public.web) {
    return(1)
  }
  else {
    return(.set.mSet(mSetObj))
  }
}

xytrans2 <- function(xy, par) {
  cbind(par[1] + ((par[2] - par[1]) * xy[, 1]),
        par[3] + ((par[4] - par[3]) * xy[, 2]))
}

xytrans <- function(xy, par) {
  cbind((xy[, 1] - par[1]) / (par[2] - par[1]),
        (xy[, 2] - par[3]) / (par[4] - par[3]))
}

plt2fig <- function(xy, dev = dev.cur()) {
  olddev <- dev.cur()
  dev.set(dev)
  plt <- par("plt")
  dev.set(olddev)
  xytrans2(xy, plt)
}

fig2dev <- function(xy, dev = dev.cur()) {
  olddev <- dev.cur()
  dev.set(dev)
  fig <- par("fig")
  dev.set(olddev)
  xytrans2(xy, fig)
}

usr2plt <- function(xy, dev = dev.cur()) {
  olddev <- dev.cur()
  dev.set(dev)
  usr <- par("usr")
  dev.set(olddev)
  xytrans(xy, usr)
}

usr2dev <- function(xy, dev = dev.cur()) {
  fig2dev(plt2fig(usr2plt(xy, dev), dev), dev)
}

CalculateCircleInfo <- function(x, y, r, width, height, lbls) {
  jscode <- paste("leftImgWidth = ", width, "\n", "leftImgHeight = ", height, sep = "");
  dot.len <- length(r);
  for (i in 1:dot.len) {
    xy <- cbind(c(x[i], r[i], 0), c(y[i], 0, 0));
    xy <- usr2dev(xy, dev.cur());
    xyrc <- cbind(ceiling(xy[, 1] * width), ceiling((1 - xy[, 2]) * height));
    radius <- abs(xyrc[2, 1] - xyrc[3, 1]);
    #add code for mouseover locations, basically the annotation info
    #in this case, the name of the node
    jscode <- paste(jscode, paste("circleArray.push({xc:", xyrc[1, 1], ", yc:", xyrc[1, 2],
                                  ", r:", radius, ", lb: \"", lbls[i], "\"})", sep = ""), sep = "\n");
  }

  return(jscode);
}

setRendAttrs = function(g, AllBorder = "transparent",
                        AllFixedsize = FALSE, AllFontsize = 16, AllShape = "rectangle",
                        fillcolor = "lightgreen", ...) {
  nn = KEGGgraph::nodes(g)
  numn = length(nn)
  color = rep(AllBorder, numn)
  names(color) = nn
  fixedsize = rep(AllFixedsize, numn)
  names(fixedsize) = nn
  if (length(fillcolor) == 1) {
    fillcolvec = rep(fillcolor, numn)
    names(fillcolvec) = nn
  } else if (!identical(names(fillcolor), as.vector(KEGGgraph::nodes(g)))) {
    stop("names on vector fillcolor must match nodes(g) exactly")
  } else {
    fillcolvec = fillcolor
  }
  shape = rep(AllShape, numn)
  names(shape) = nn
  fontsize = rep(AllFontsize, numn)
  names(fontsize) = nn;
  list(color = color, fixedsize = fixedsize, fillcolor = fillcolvec, shape = shape,
       fontsize = fontsize)
}

setRendAttrsWithName = function(g, AllBorder = "transparent",
                                AllFixedsize = FALSE, AllFontsize = 17, AllShape = "rectangle",
                                fillcolor = "lightgreen", diffData, ...) {
  nn = KEGGgraph::nodes(g)
  numn = length(nn)
  color = rep(AllBorder, numn)
  names(color) = nn
  fixedsize = rep(AllFixedsize, numn)
  names(fixedsize) = nn
  if (length(fillcolor) == 1) {
    fillcolvec = rep(fillcolor, numn)
    names(fillcolvec) = nn
  } else if (!identical(names(fillcolor), as.vector(KEGGgraph::nodes(g)))) {
    stop("names on vector fillcolor must match nodes(g) exactly")
  } else {
    fillcolvec = fillcolor
  }
  shape = rep(AllShape, numn)
  names(shape) = nn
  fontsize = rep(AllFontsize, numn)
  names(fontsize) = nn
  nnDf <- tibble(name = names(nn), kegg = nn)
  newLabels <- nn %>%
    map_chr(function(x) {
      name <- diffData %>%
        filter(KEGG == x) %>%
        head(1) %>%
        .$Metabolite
      finalName <- if (length(name) == 0) {
        nnDf %>%
          filter(kegg == x) %>%
          .$name
      }else name
      finalName
    })
  labels <- newLabels
  names(labels) <- nn
  widths = rep(0.01, numn)
  names(widths) = nn
  heights = rep(1, numn)
  names(heights) = nn
  list(color = color, fixedsize = fixedsize, fillcolor = fillcolvec, shape = shape,
       fontsize = fontsize, label = labels, width = widths)
}

KEGGID2HMDBID <- function(ids, dataDir) {
  cmpd.db <- .read.metaboanalyst.lib("compound_db.rds", dataDir);

  hit.inx <- match(ids, cmpd.db$kegg);
  return(cmpd.db[hit.inx, "hmdb_id"]);
}

GetMetPANodeInfo <- function(pathName, object, tags, histvec, pvec, impvec, width, height, usr = par("usr"), dataDir) {
  nn = sapply(Rgraphviz::AgNode(object), function(x) x@name);
  ## transform user to pixel coordinates
  x.u2p = function(x) { rx = (x - usr[1]) / diff(usr[1:2]); stopifnot(all(rx >= 0 & rx <= 1)); return(rx * width) }
  y.u2p = function(y) { ry = (usr[4] - y) / diff(usr[3:4]); stopifnot(all(ry >= 0 & ry <= 1)); return(ry * height) }

  nxy = Rgraphviz::getNodeXY(object);
  nh = Rgraphviz::getNodeHeight(object) / 2;
  xl = floor(x.u2p(nxy$x - Rgraphviz::getNodeLW(object)));
  xr = ceiling(x.u2p(nxy$x + Rgraphviz::getNodeRW(object)));
  yu = floor(y.u2p(nxy$y - nh));
  yl = ceiling(y.u2p(nxy$y + nh));
  names(xl) = names(xr) = names(yu) = names(yl) = nn;
  # create the javascript code
  jscode <- paste("keggPathLnk=\'<a href=\"javascript:void(0);\" onclick=\"window.open(\\'http://www.genome.jp/kegg-bin/show_pathway?", metpa$path.ids[pathName], "\\',\\'KEGG\\');\">", pathName, "</a>\'", sep = "");
  tag.ids <- names(tags);
  kegg.ids <- names(tags);
  hmdb.ids <- KEGGID2HMDBID(kegg.ids, dataDir = dataDir)
  for (i in 1:length(tag.ids)) {
    nd <- tag.ids[i];
    x1 <- floor(100 * (xl[nd]) / width);
    x2 <- ceiling(100 * (xr[nd]) / width);
    y1 <- floor(100 * (yl[nd]) / height);
    y2 <- ceiling(100 * (yu[nd]) / height);
    #add code for mouseover locations, basically the annotation info
    #in this case, the name of the node
    jscode <- paste(jscode, paste("rectArray.push({x1:", x1, ", y1:", y1, ", x2:", x2, ", y2:", y2,
                                  ", lb: \"", tags[i], "\", kegg: \"", kegg.ids[i], "\", hmdb: \"", hmdb.ids[i],
                                  "\", icon: \"", histvec[i], "\", pvalue: \"", pvec[i], "\", impact: \"", impvec[i], "\"})", sep = ""), sep = "\n");
  }
  return(jscode);
}

PlotMetpaPath <- function(mSetObj = NA, pathName, width = NA, height = NA, dataDir, parent, fcData)
{
  path.id <- metpa$path.ids[pathName]
  g <- metpa$graph.list[[path.id]]
  print(g)
  tooltip <- names(KEGGgraph::nodes(g))
  nm.vec <- NULL
  fillcolvec <- rep("lightgrey", length(KEGGgraph::nodes(g)))
  pvec <- histvec <- rep("NA", length(KEGGgraph::nodes(g)))
  names(tooltip) <- names(fillcolvec) <- names(histvec) <- names(pvec) <- KEGGgraph::nodes(g)
  if (mSetObj$analSet$type == "pathora") {
    if (!is.null(mSetObj$analSet$ora.hits)) {
      names <- mSetObj$analSet$ora.hits[[path.id]]
      cols <- fcData %>%
        filter(KEGG %in% names) %>%
        arrange(KEGG = factor(KEGG, levels = names)) %>%
        .$col
      fillcolvec[mSetObj$analSet$ora.hits[[path.id]]] <- cols
      if (mSetObj$dataSet$use.metabo.filter && !is.null(mSetObj$analSet$ora.filtered.mset)) {
        fillcolvec[!(names(fillcolvec) %in% mSetObj$analSet$ora.filtered.mset[[path.id]])] <- "lightgrey"
      }
    }
  }
  if (is.null(mSetObj$analSet$node.imp) || mSetObj$analSet$node.imp ==
    "rbc") {
    impvec <- metpa$rbc[[path.id]]
  }
  else {
    impvec <- metpa$dgr[[path.id]]
  }
  imgName <- paste(parent, "/", pathName, ".pdf", sep = "")
  pdf(file = imgName, width = width, height = height, bg = "white")
  par(mai = rep(0, 4))
  g.obj <- plot(g, nodeAttrs = setRendAttrs(g, fillcolor = fillcolvec))
  nodeInfo <- GetMetPANodeInfo(pathName, g.obj, tooltip,
                               histvec, pvec, impvec, width, height, dataDir = dataDir)
  dev.off()
  mSetObj$imgSet$current.metpa.graph <- g.obj
  mSetObj$analSet$nodeInfo <- nodeInfo
  if (.on.public.web) {
    .set.mSet(mSetObj)
    return(nodeInfo)
  }
  else {
    return(.set.mSet(mSetObj))
  }
}

PlotMetpaPathByName <- function(mSetObj = NA, pathName, width = NA, height = NA, dataDir, parent, fcData, diffData)
{
  path.id <- metpa$path.ids[pathName]
  g <- metpa$graph.list[[path.id]]
  print(g)
  tooltip <- names(KEGGgraph::nodes(g))
  nm.vec <- NULL
  fillcolvec <- rep("lightgrey", length(KEGGgraph::nodes(g)))
  pvec <- histvec <- rep("NA", length(KEGGgraph::nodes(g)))
  names(tooltip) <- names(fillcolvec) <- names(histvec) <- names(pvec) <- KEGGgraph::nodes(g)
  if (mSetObj$analSet$type == "pathora") {
    if (!is.null(mSetObj$analSet$ora.hits)) {
      names <- mSetObj$analSet$ora.hits[[path.id]]
      cols <- fcData %>%
        filter(KEGG %in% names) %>%
        arrange(KEGG = factor(KEGG, levels = names)) %>%
        .$col
      fillcolvec[mSetObj$analSet$ora.hits[[path.id]]] <- cols
      if (mSetObj$dataSet$use.metabo.filter && !is.null(mSetObj$analSet$ora.filtered.mset)) {
        fillcolvec[!(names(fillcolvec) %in% mSetObj$analSet$ora.filtered.mset[[path.id]])] <- "lightgrey"
      }
    }
  }
  if (is.null(mSetObj$analSet$node.imp) || mSetObj$analSet$node.imp ==
    "rbc") {
    impvec <- metpa$rbc[[path.id]]
  }
  else {
    impvec <- metpa$dgr[[path.id]]
  }
  imgName <- paste(parent, "/", pathName, ".pdf", sep = "")
  pdf(file = imgName, width = width, height = height, bg = "white")
  par(mai = rep(0, 4))
  g.obj <- plot(g, nodeAttrs = setRendAttrsWithName(g, fillcolor = fillcolvec, diffData = diffData))
  nodeInfo <- GetMetPANodeInfo(pathName, g.obj, tooltip,
                               histvec, pvec, impvec, width, height, dataDir = dataDir)
  dev.off()
  mSetObj$imgSet$current.metpa.graph <- g.obj
  mSetObj$analSet$nodeInfo <- nodeInfo
  if (.on.public.web) {
    .set.mSet(mSetObj)
    return(nodeInfo)
  }
  else {
    return(.set.mSet(mSetObj))
  }
}

LoadMsetLib <- function(libname = "kegg_pathway", dataDir)
{
  if (!exists("current.msetlib") || "current.msetlib$lib.name" !=
    libname) {
    .load.metaboanalyst.lib("msets", libname, dataDir = dataDir)
  }
}

SetCurrentMsetLib <- function(mSetObj = NA, lib.type, excludeNum = 0, dataDir)
{
  mSetObj <- .get.mSet(mSetObj)
  if (lib.type != "self") {
    LoadMsetLib(lib.type, dataDir = dataDir)
  }
  if (lib.type == "self") {
    ms.list <- mSetObj$dataSet$user.mset
    current.msetlib <- data.frame(name = character(), member = character(),
                                  reference = character(), stringsAsFactors = FALSE)
  }
  else {
    ms.list <- strsplit(current.msetlib[, 3], "; ")
    names(ms.list) <- current.msetlib[, 2]
  }

  if (excludeNum > 0) {
    cmpd.count <- lapply(ms.list, length)
    sel.inx <- cmpd.count >= excludeNum
    ms.list <- ms.list[sel.inx]
    current.msetlib <- current.msetlib[sel.inx,]
  }
  mSetObj$dataSet$uniq.count <- length(unique(unlist(ms.list,
                                                     use.names = FALSE)))
  current.msetlib$member <- ms.list
  current.msetlib <<- current.msetlib
  if (.on.public.web) {
    .set.mSet(mSetObj)
  }
  return(list(mSet = .set.mSet(mSetObj), cMsetlib = current.msetlib))
}

CalculateHyperScore <- function(mSetObj = NA, dataDir, fileName, diffData)
{
  mSetObj <- .get.mSet(mSetObj)
  nm.map <- GetFinalNameMap(mSetObj, dataDir = dataDir)
  valid.inx <- !(is.na(nm.map$hmdb) | duplicated(nm.map$hmdb))
  ora.vec <- nm.map$hmdb[valid.inx]
  q.size <- length(ora.vec)
  if (is.na(ora.vec) || q.size == 0) {
    AddErrMsg("No valid HMDB compound names found!")
    return(0)
  }
  current.mset <- current.msetlib$member
  if (mSetObj$dataSet$use.metabo.filter && !is.null(mSetObj$dataSet$metabo.filter.hmdb)) {
    current.mset <- lapply(current.mset, function(x) {
      x[x %in% mSetObj$dataSet$metabo.filter.hmdb]
    })
    mSetObj$dataSet$filtered.mset <- current.mset
  }
  uniq.count <- length(unique(unlist(current.mset, use.names = FALSE)))
  set.size <- length(current.mset)
  if (set.size == 1) {
    AddErrMsg("Cannot perform enrichment analysis on a single metabolite set!")
    return(0)
  }
  hits <- lapply(current.mset, function(x) {
    x[x %in% ora.vec]
  })
  hit.num <- unlist(lapply(hits, function(x) length(x)), use.names = FALSE)
  if (sum(hit.num > 0) == 0) {
    AddErrMsg("No match was found to the selected metabolite set library!")
    return(0)
  }
  set.num <- unlist(lapply(current.mset, length), use.names = FALSE)
  res.mat <- matrix(NA, nrow = set.size, ncol = 6)
  rownames(res.mat) <- names(current.mset)
  colnames(res.mat) <- c("Total", "Expected", "Hits", "Raw P",
                         "Holm P", "FDR")
  for (i in 1:set.size) {
    res.mat[i, 1] <- set.num[i]
    res.mat[i, 2] <- q.size * (set.num[i] / uniq.count)
    res.mat[i, 3] <- hit.num[i]
    res.mat[i, 4] <- phyper(hit.num[i] - 1, set.num[i], uniq.count -
      set.num[i], q.size, lower.tail = F)
  }

  enrichNames <- c(1:set.size) %>%
    map(~hits[.x]) %>%
    map_chr(function(x) {
      xVec <- x %>%
        unlist()
      ifelse(length(xVec) > 0, str_c(xVec, collapse = "\n"), "")
    })

  res.mat[, 5] <- p.adjust(res.mat[, 4], "holm")
  res.mat[, 6] <- p.adjust(res.mat[, 4], "fdr")

  save.mat <- res.mat %>%
    as.data.frame() %>%
    rownames_to_column("name") %>%
    add_column(Enriched_Compounds = enrichNames) %>%
    filter(Hits > 0) %>%
    arrange(`Raw P`) %>%
    mutate_at(vars(-c("name", "Enriched_Compounds")), ~signif(.x, 3))

  mSetObj$analSet$ora.mat <- save.mat %>%
    select(-c("Enriched_Compounds")) %>%
    column_to_rownames("name") %>%
    as.matrix()
  mSetObj$analSet$ora.hits <- hits

  save.mat <- save.mat %>%
    column_to_rownames("name")

  outTb <- save.mat %>%
    rownames_to_column("Metabolite") %>%
    rowwise() %>%
    do({
      result <- as_tibble(.)
      enrichCompounds <- result$Enriched_Compounds %>%
        as.character()
      names <- str_split(enrichCompounds, "\n") %>%
        unlist() %>%
        map_chr(function(x) {
          cNumber <- nm.map %>%
            filter(hmdb == x) %>%
            .$kegg
          name <- diffData %>%
            filter(KEGG == cNumber) %>%
            head(1) %>%
            .$Metabolite
          name
        })
      name <- str_c(names, collapse = "\n")
      df <- result %>%
        mutate(Enriched_Compounds = name)
      df
    }) %>%
    ungroup() %>%
    rename(` ` = Metabolite)

  write_csv(outTb, fileName)
  if (.on.public.web) {
    .set.mSet(mSetObj)
    return(1)
  }
  return(.set.mSet(mSetObj))
}

GetShortNames <- function(nm.vec, max.len = 45) {
  new.nms <- vector(mode = "character", length = length(nm.vec));
  for (i in 1:length(nm.vec)) {
    nm <- nm.vec[i];
    if (nchar(nm) <= max.len) {
      new.nms[i] <- nm;
    }else {
      wrds <- strsplit(nm, "[[:space:]]+")[[1]];
      new.nm <- "";
      if (length(wrds) > 1) {
        for (m in 1:length(wrds)) {
          wrd <- wrds[m];
          if (nchar(new.nm) + 4 + nchar(wrd) <= max.len) {
            new.nm <- paste(new.nm, wrd);
          }else {
            new.nms[i] <- paste(new.nm, "...", sep = "");
            break;
          }
        }
      }else {
        new.nms[i] <- paste(substr(nm, 0, 21), "...", sep = "");
      }
    }
  }
  return(new.nms);
}

PlotMSEA.Overview <- function(folds, pvals)
{
  title <- "Metabolite Sets Enrichment Overview"
  if (length(folds) > 50) {
    folds <- folds[1:50]
    pvals <- pvals[1:50]
    title <- "Enrichment Overview (top 50)"
  }
  op <- par(mar = c(5, 20, 4, 6), oma = c(0, 0, 0, 4))
  ht.col <- rev(heat.colors(length(folds)))
  barplot(rev(folds), horiz = T, col = ht.col, xlab = "Fold Enrichment",
          las = 1, cex.name = 0.75, space = c(0.5, 0.5), main = title)
  minP <- min(pvals)
  maxP <- max(pvals)
  medP <- (minP + maxP) / 2
  axs.args <- list(at = c(minP, medP, maxP), labels = format(c(maxP,
                                                               medP, minP), scientific = T, digit = 1), tick = F)
  image.plot(legend.only = TRUE, zlim = c(minP, maxP), col = ht.col,
             axis.args = axs.args, legend.shrink = 0.4, legend.lab = "P value")
  par(op)
}

image.plot <- function(..., add = FALSE, nlevel = 64,
                       horizontal = FALSE, legend.shrink = 0.9, legend.width = 1.2,
                       legend.mar = ifelse(horizontal, 3.1, 5.1), legend.lab = NULL,
                       graphics.reset = FALSE, bigplot = NULL, smallplot = NULL,
                       legend.only = FALSE, col = tim.colors(nlevel), lab.breaks = NULL,
                       axis.args = NULL, legend.args = NULL, midpoint = FALSE) {
  old.par <- par(no.readonly = TRUE)
  #  figure out zlim from passed arguments
  info <- image.plot.info(...)
  if (add) {
    big.plot <- old.par$plt
  }
  if (legend.only) {
    graphics.reset <- TRUE
  }
  if (is.null(legend.mar)) {
    legend.mar <- ifelse(horizontal, 3.1, 5.1)
  }
  #
  # figure out how to divide up the plotting real estate.
  #
  temp <- image.plot.plt(add = add, legend.shrink = legend.shrink,
                         legend.width = legend.width, legend.mar = legend.mar,
                         horizontal = horizontal, bigplot = bigplot, smallplot = smallplot)
  #
  # bigplot are plotting region coordinates for image
  # smallplot are plotting coordinates for legend
  smallplot <- temp$smallplot
  bigplot <- temp$bigplot
  #
  # draw the image in bigplot, just call the R base function
  # or poly.image for polygonal cells note logical switch
  # for poly.grid parsed out of call from image.plot.info
  if (!legend.only) {
    if (!add) {
      par(plt = bigplot)
    }
    if (!info$poly.grid) {
      image(..., add = add, col = col)
    }
    else {
      poly.image(..., add = add, col = col, midpoint = midpoint)
    }
    big.par <- par(no.readonly = TRUE)
  }
  ##
  ## check dimensions of smallplot
  if ((smallplot[2] < smallplot[1]) | (smallplot[4] < smallplot[3])) {
    par(old.par)
    stop("plot region too small to add legend\n")
  }
  # Following code draws the legend using the image function
  # and a one column image.
  # calculate locations for colors on legend strip
  ix <- 1
  minz <- info$zlim[1]
  maxz <- info$zlim[2]
  binwidth <- (maxz - minz) / nlevel
  midpoints <- seq(minz + binwidth / 2, maxz - binwidth / 2, by = binwidth)
  iy <- midpoints
  iz <- matrix(iy, nrow = 1, ncol = length(iy))
  # extract the breaks from the ... arguments
  # note the breaks delineate intervals of common color
  breaks <- list(...)$breaks
  # draw either horizontal or vertical legends.
  # using either suggested breaks or not -- a total of four cases.
  #
  # next par call sets up a new plotting region just for the legend strip
  # at the smallplot coordinates
  par(new = TRUE, pty = "m", plt = smallplot, err = -1)
  # create the argument list to draw the axis
  #  this avoids 4 separate calls to axis and allows passing extra
  # arguments.
  # then add axis with specified lab.breaks at specified breaks
  if (!is.null(breaks) & !is.null(lab.breaks)) {
    # axis with labels at break points
    axis.args <- c(list(side = ifelse(horizontal, 1, 4),
                        mgp = c(3, 1, 0), las = ifelse(horizontal, 0, 2),
                        at = breaks, labels = lab.breaks), axis.args)
  }
  else {
    # If lab.breaks is not specified, with or without breaks, pretty
    # tick mark locations and labels are computed internally,
    # or as specified in axis.args at the function call
    axis.args <- c(list(side = ifelse(horizontal, 1, 4),
                        mgp = c(3, 1, 0), las = ifelse(horizontal, 0, 2)),
                   axis.args)
  }
  #
  # draw color scales the four cases are horizontal/vertical breaks/no breaks
  # add a label if this is passed.
  if (!horizontal) {
    if (is.null(breaks)) {
      image(ix, iy, iz, xaxt = "n", yaxt = "n", xlab = "",
            ylab = "", col = col)
    }
    else {
      image(ix, iy, iz, xaxt = "n", yaxt = "n", xlab = "",
            ylab = "", col = col, breaks = breaks)
    }
  }
  else {
    if (is.null(breaks)) {
      image(iy, ix, t(iz), xaxt = "n", yaxt = "n", xlab = "",
            ylab = "", col = col)
    }
    else {
      image(iy, ix, t(iz), xaxt = "n", yaxt = "n", xlab = "",
            ylab = "", col = col, breaks = breaks)
    }
  }
  #
  # now add the axis to the legend strip.
  # notice how all the information is in the list axis.args
  #
  do.call("axis", axis.args)
  # add a box around legend strip
  box()
  #
  # add a label to the axis if information has been  supplied
  # using the mtext function. The arguments to mtext are
  # passed as a list like the drill for axis (see above)
  #
  if (!is.null(legend.lab)) {
    legend.args <- list(text = legend.lab, side = ifelse(horizontal,
                                                         1, 3), line = 1)
  }
  #
  # add the label using mtext function
  if (!is.null(legend.args)) {
    do.call(mtext, legend.args)
  }
  #
  #
  # clean up graphics device settings
  # reset to larger plot region with right user coordinates.
  mfg.save <- par()$mfg
  if (graphics.reset | add) {
    par(old.par)
    par(mfg = mfg.save, new = FALSE)
    invisible()
  }
  else {
    par(big.par)
    par(plt = big.par$plt, xpd = FALSE)
    par(mfg = mfg.save, new = FALSE)
    invisible()
  }
}

"image.plot.info" <- function(...) {
  temp <- list(...)
  #
  xlim <- NA
  ylim <- NA
  zlim <- NA
  poly.grid <- FALSE
  #
  # go through various cases of what these can be
  #
  ##### x,y,z list is first argument
  if (is.list(temp[[1]])) {
    xlim <- range(temp[[1]]$x, na.rm = TRUE)
    ylim <- range(temp[[1]]$y, na.rm = TRUE)
    zlim <- range(temp[[1]]$z, na.rm = TRUE)
    if (is.matrix(temp[[1]]$x) &
      is.matrix(temp[[1]]$y) &
      is.matrix(temp[[1]]$z)) {
      poly.grid <- TRUE
    }
  }
  ##### check for polygrid first three arguments should be matrices
  #####
  if (length(temp) >= 3) {
    if (is.matrix(temp[[1]]) &
      is.matrix(temp[[2]]) &
      is.matrix(temp[[3]])) {
      poly.grid <- TRUE
    }
  }
  #####  z is passed without an  x and y  (and not a poly.grid!)
  #####
  if (is.matrix(temp[[1]]) & !poly.grid) {
    xlim <- c(0, 1)
    ylim <- c(0, 1)
    zlim <- range(temp[[1]], na.rm = TRUE)
  }
  ##### if x,y,z have all been passed find their ranges.
  ##### holds if poly.grid or not
  #####
  if (length(temp) >= 3) {
    if (is.matrix(temp[[3]])) {
      xlim <- range(temp[[1]], na.rm = TRUE)
      ylim <- range(temp[[2]], na.rm = TRUE)
      zlim <- range(temp[[3]], na.rm = TRUE)
    }
  }
  #### parse x,y,z if they are  named arguments
  # determine if  this is polygon grid (x and y are matrices)
  if (is.matrix(temp$x) &
    is.matrix(temp$y) &
    is.matrix(temp$z)) {
    poly.grid <- TRUE
  }
  xthere <- match("x", names(temp))
  ythere <- match("y", names(temp))
  zthere <- match("z", names(temp))
  if (!is.na(zthere))
    zlim <- range(temp$z, na.rm = TRUE)
  if (!is.na(xthere))
    xlim <- range(temp$x, na.rm = TRUE)
  if (!is.na(ythere))
    ylim <- range(temp$y, na.rm = TRUE)
  # overwrite zlims with passed values
  if (!is.null(temp$zlim))
    zlim <- temp$zlim
  if (!is.null(temp$xlim))
    xlim <- temp$xlim
  if (!is.null(temp$ylim))
    ylim <- temp$ylim
  list(xlim = xlim, ylim = ylim, zlim = zlim, poly.grid = poly.grid)
}

image.plot.plt <- function(x, add = FALSE, legend.shrink = 0.9,
                           legend.width = 1, horizontal = FALSE, legend.mar = NULL,
                           bigplot = NULL, smallplot = NULL, ...) {
  old.par <- par(no.readonly = TRUE)
  if (is.null(smallplot))
    stick <- TRUE
  else stick <- FALSE
  if (is.null(legend.mar)) {
    legend.mar <- ifelse(horizontal, 3.1, 5.1)
  }
  # compute how big a text character is
  char.size <- ifelse(horizontal, par()$cin[2] / par()$din[2],
                      par()$cin[1] / par()$din[1])
  # This is how much space to work with based on setting the margins in the
  # high level par command to leave between strip and big plot
  offset <- char.size * ifelse(horizontal, par()$mar[1], par()$mar[4])
  # this is the width of the legned strip itself.
  legend.width <- char.size * legend.width
  # this is room for legend axis labels
  legend.mar <- legend.mar * char.size
  # smallplot is the plotting region for the legend.
  if (is.null(smallplot)) {
    smallplot <- old.par$plt
    if (horizontal) {
      smallplot[3] <- legend.mar
      smallplot[4] <- legend.width + smallplot[3]
      pr <- (smallplot[2] - smallplot[1]) * ((1 - legend.shrink) / 2)
      smallplot[1] <- smallplot[1] + pr
      smallplot[2] <- smallplot[2] - pr
    }
    else {
      smallplot[2] <- 1 - legend.mar
      smallplot[1] <- smallplot[2] - legend.width
      pr <- (smallplot[4] - smallplot[3]) * ((1 - legend.shrink) / 2)
      smallplot[4] <- smallplot[4] - pr
      smallplot[3] <- smallplot[3] + pr
    }
  }
  if (is.null(bigplot)) {
    bigplot <- old.par$plt
    if (!horizontal) {
      bigplot[2] <- min(bigplot[2], smallplot[1] - offset)
    }
    else {
      bottom.space <- old.par$mar[1] * char.size
      bigplot[3] <- smallplot[4] + offset
    }
  }
  if (stick & (!horizontal)) {
    dp <- smallplot[2] - smallplot[1]
    smallplot[1] <- min(bigplot[2] + offset, smallplot[1])
    smallplot[2] <- smallplot[1] + dp
  }
  return(list(smallplot = smallplot, bigplot = bigplot))
}

PlotEnrichNet.Overview <- function(folds, pvals, layoutOpt = layout.fruchterman.reingold, parent)
{
  title <- "Enrichment Network Overview"
  if (length(folds) > 50) {
    folds <- folds[1:50]
    pvals <- pvals[1:50]
    title <- "Enrichment Overview (top 50)"
  }
  if (.on.public.web) {
    load_igraph()
    load_reshape()
  }
  pvalue <- pvals
  id <- names(pvalue)
  geneSets <- current.msetlib$member
  n <- length(pvalue)
  w <- matrix(NA, nrow = n, ncol = n)
  colnames(w) <- rownames(w) <- id
  for (i in 1:n) {
    for (j in i:n) {
      w[i, j] = overlap_ratio(geneSets[id[i]], geneSets[id[j]])
    }
  }
  wd <- melt(w)
  wd <- wd[wd[, 1] != wd[, 2],]
  wd <- wd[!is.na(wd[, 3]),]
  g <- graph.data.frame(wd[, -3], directed = F)
  E(g)$width <- sqrt(wd[, 3] * 20)
  g <- delete.edges(g, E(g)[wd[, 3] < 0.2])
  idx <- unlist(sapply(V(g)$name, function(x) which(x == id)))
  cols <- color_scale("red", "#E5C494")
  V(g)$color <- cols[sapply(pvalue, getIdx, min(pvalue), max(pvalue))]
  cnt <- folds
  names(cnt) <- id
  cnt2 <- cnt[V(g)$name] + 1
  V(g)$size <- cnt2 / sum(cnt2) * 100
  pos.xy <- layout.fruchterman.reingold(g, niter = 500)
  nodes <- vector(mode = "list")
  node.nms <- V(g)$name
  node.sizes <- V(g)$size
  node.cols <- V(g)$color
  if (length(node.sizes) == 0) {
    return(NULL)
  }

  for (i in 1:length(node.sizes)) {
    nodes[[i]] <- list(id = node.nms[i], label = node.nms[i],
                       size = node.sizes[i], color = node.cols[i], x = pos.xy[i,
                                                                              1], y = pos.xy[i, 2])
  }

  edge.mat <- get.edgelist(g)
  edge.mat <- cbind(id = 1:nrow(edge.mat), source = edge.mat[,
    1], target = edge.mat[, 2])
  netData <- list(nodes = nodes, edges = edge.mat)
  sink(str_c(parent, "/MSEA_Network.json"))
  cat(RJSONIO::toJSON(netData))
  sink()
  return(g)
}

overlap_ratio <- function(x, y) {
  x <- unlist(x)
  y <- unlist(y)
  length(intersect(x, y)) / length(unique(c(x, y)))
}

color_scale <- function(c1 = "grey", c2 = "red") {
  pal <- colorRampPalette(c(c1, c2))
  colors <- pal(100)
  return(colors)
}

getIdx <- function(v, MIN, MAX) {
  if (MIN == MAX) {
    return(100)
  }
  intervals <- seq(MIN, MAX, length.out = 100)
  max(which(intervals <= v))
}

SetSMPDB.PathLib <- function(mSetObj = NA, smpdb.rda, dataDir)
{
  mSetObj <- .get.mSet(mSetObj)
  mSetObj$msgSet$lib.msg <- paste("Your selected pathway library code is \\textbf{",
                                  smpdb.rda, "}(KEGG organisms abbreviation).")
  smpdblib <- .load.metaboanalyst.lib("smpdb", smpdb.rda, dataDir = dataDir)
  mSetObj$pathwaylibtype <- "SMPDB"
  if (.on.public.web) {
    .set.mSet(mSetObj)
    return(1)
  }
  return(.set.mSet(mSetObj))
}

SetOrganism <- function(mSetObj = NA, org)
{
  mSetObj <- .get.mSet(mSetObj)
  pathinteg.org <<- data.org <<- org
  return(.set.mSet(mSetObj))
}

smpdbpw.count <- 0

GeneratePathwayJSON <- function(mSetObj = NA, pathway.nm, dataDir, data.org, parent) {
  mSetObj <- .get.mSet(mSetObj);
  smpdb.path <- paste(dataDir, "/smpdb/", data.org, ".rda", sep = "");
  load(smpdb.path)

  jsons.path <- paste(dataDir, "/smpdb/jsons/", data.org, ".rds", sep = "");
  smpdb.jsons <- readRDS(jsons.path) # no need to be global!

  if (pathway.nm == "top") {
    if (mSetObj$analSet$type == "pathora") {
      pathway.id <- rownames(mSetObj$analSet$ora.mat)[1]
    } else {
      pathway.id <- rownames(mSetObj$analSet$qea.mat)[1]
    }
    pathway.nm <- names(metpa$path.ids)[which(metpa$path.ids == pathway.id)]
  } else {
    pathway.id <- metpa$path.ids[which(names(metpa$path.ids) == pathway.nm)]
  }
  # Get matched metabolites
  if (mSetObj$analSet$type == "pathora") {
    metab.matches <- paste(mSetObj$analSet$ora.hits[[pathway.id]], collapse = ",");
  } else {
    metab.matches <- paste(mSetObj$analSet$qea.hits[[pathway.id]], collapse = ",");
  }

  title <- paste(pathway.id, ";", pathway.nm, sep = "");
  # store json file
  smpdbpw.nm <- paste(parent, "/", pathway.nm, ".json", sep = "");
  smpdbpw.count <<- smpdbpw.count + 1;
  g <- smpdb.jsons[[pathway.id]]
  sink(smpdbpw.nm)
  cat(jsonlite::toJSON(g, pretty = TRUE));
  sink()

  smpdbpw.nm <- paste0(smpdbpw.nm, ";", metab.matches, ";", title)
  return(smpdbpw.nm)
}