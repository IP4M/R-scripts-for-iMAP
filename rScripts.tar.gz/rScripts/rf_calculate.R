# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/7/24

library(ggrepel)
library(ropls)
library(pROC)
library(egg)
library(stringr)
library(randomForest)
library(Boruta)
library(magrittr)
library(optparse)
library(tidyverse)

createWhenNoExist <- function(f) {
  !dir.exists(f) && dir.create(f)
}

option_list <- list(
  make_option("--i", default = "AllMet_Raw.txt", type = "character", help = "metabolite data file"),
  make_option("--g", default = "group.txt", type = "character", help = "sample group file"),
  make_option("--sc", default = "sample_color.txt", type = "character", help = "sample color file"),
  make_option("--config", default = "calculate_config.txt", type = "character", help = "config file")

)
opt <- parse_args(OptionParser(option_list = option_list))

options(digits = 3)

args <- commandArgs(trailingOnly = F)
scriptPath <- dirname(sub("--file=", "", args[grep("--file", args)]))
source(str_c(scriptPath, "/base.R"))

sampleInfo <- read_tsv(opt$g) %>%
  rename(SampleID = Sample) %>%
  select(c("SampleID", "ClassNote"))

head(sampleInfo)

parent <- paste0("./")
createWhenNoExist(parent)

data <- read_tsv(opt$i) %>%
  gather("SampleID", "Value", -Metabolite) %>%
  spread(Metabolite, "Value") %>%
  inner_join(sampleInfo, by = c("SampleID")) %>%
  column_to_rownames("SampleID") %>%
  mutate(ClassNote = factor(ClassNote, levels = unique(ClassNote))) %>%
  as.data.frame()

x <- data %>% select(-c("ClassNote"))
y <- data$ClassNote

configData <- read_tsv(opt$config, col_names = F) %>%
  set_colnames(c("arg", "value"))

ntree <- configGet(configData, "ntree") %>%
  as.numeric()
hasMtry <- configGet(configData, "hasMtry")   %>%
  as.logical()
mtry <- if (hasMtry) {
  configGet(configData, "mtry") %>%
    as.numeric()
}else {
  if (!is.null(y) && !is.factor(y))
    max(floor(ncol(x) / 3), 1) else floor(sqrt(ncol(x)))
}
hasNodesize <- configGet(configData, "hasNodesize") %>%
  as.logical()
nodesize <- if (hasNodesize) {
  configGet(configData, "nodesize") %>%
    as.numeric()
}else {
  if (!is.null(y) && !is.factor(y)) 5 else 1
}
hasMaxnodes <- configGet(configData, "hasMaxnodes")  %>%
  as.logical()
maxnodes <- if (hasMaxnodes) {
  configGet(configData, "maxnodes") %>%
    as.numeric()
}else {
  NULL
}

replace <- configGet(configData, "replace") %>%
  as.logical()
rfRs <- randomForest(x, y, importance = T, proximity = TRUE, ntree = ntree, mtry = mtry, replace = replace,
                     nodesize = nodesize)

importance <- rfRs$importance %>%
  as.data.frame() %>%
  rownames_to_column("Metabolite") %>%
  select(c("Metabolite", "MeanDecreaseGini")) %>%
  arrange(desc(MeanDecreaseGini))
importance
write.csv(importance, "RF_Imp_Rank.csv", row.names = F)












