# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/8/12
library(optparse)
library(tidyverse)

gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}

getClassCols <- function(n) {
  inCols <- c("#00FFFF", "#0099FF", "#8A4198", "#FF6F00", "#CC9999", "#FFFF00", "#00FF7F", "#CCFFCC", "#336666",
              "#FF6666", "#FFCC33", "#CC3399")
  extraColors <- c("#CD0000", "#3A89CC", "#769C30", "#D99536", "#7B0078", "#BFBC3B", "#6E8B3D", "#00688B", "#C10077", "#CAAA76",
                   "#EEEE00", "#458B00", "#8B4513", "#008B8B", "#6E8B3D", "#8B7D6B", "#7FFF00", "#CDBA96", "#ADFF2F")
  orignalCols <- c(inCols, extraColors)
  on <- length(orignalCols)
  if (n <= on) {
    orignalCols[1:n]
  }else {
    ggCols <- gg_color_hue(n - on)
    c(orignalCols, ggCols)
  }
}

option_list <- list(
  make_option("--i", default = "AllMet_with_Anno.csv", type = "character", help = "metabolite data file")
)
opt <- parse_args(OptionParser(option_list = option_list))

data <- if (str_ends(opt$i, ".csv")) {
  read_csv(opt$i)
}else read_tsv(opt$i)

classes <- data %>%
  .$Class %>%
  unique()

classCols <- getClassCols(length(classes))
classColDf <- data.frame(Class = classes, col = classCols)
write.table(classColDf, "meta_color.txt", sep = "\t", col.names = NA, quote = FALSE)


