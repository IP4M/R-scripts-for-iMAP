# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/7/24

library(ggrepel)
library(ropls)
library(pROC)
library(egg)
library(randomForest)
library(Boruta)
library(magrittr)
library(optparse)
library(caret)
library(tidyverse)

createWhenNoExist <- function(f) {
  !dir.exists(f) && dir.create(f)
}

option_list <- list(
  make_option("--i", default = "AllMet_Raw.txt", type = "character", help = "metabolite data file"),
  make_option("--g", default = "group.txt", type = "character", help = "sample group file"),
  make_option("--config", default = "calculate_config.txt", type = "character", help = "config file")
)
opt <- parse_args(OptionParser(option_list = option_list))

options(digits = 3)
args <- commandArgs(trailingOnly = F)
scriptPath <- dirname(sub("--file=", "", args[grep("--file", args)]))
source(str_c(scriptPath, "/base.R"))
configData <- read_tsv(opt$config, col_names = F) %>%
  set_colnames(c("arg", "value"))

sampleInfo <- read_tsv(opt$g) %>%
  rename(SampleID = Sample) %>%
  select(c("SampleID", "ClassNote"))

groups <- sampleInfo %>%
  .$ClassNote %>%
  unique()

initData <- read_tsv(opt$i) %>%
  gather("SampleID", "Value", -Metabolite) %>%
  spread(Metabolite, "Value")

originalColumnNames <- colnames(initData)

originalData <- initData %>%
  inner_join(sampleInfo, by = c("SampleID"))

data <- originalData %>%
  mutate(ClassNote = factor(ClassNote, levels = unique(ClassNote)))

trainData <- data %>%
  column_to_rownames("SampleID")

hasExternal <- configGet(configData, "hasExternal") %>%
  as.logical()
testSampleInfoTb <- if (hasExternal) {
  read_tsv(str_c("test_group.txt"))
}else {
  read_tsv(str_c("../preprocess_0/test_group.txt"))
}
testSampleInfo <- testSampleInfoTb %>%
  rename(SampleID = Sample) %>%
  select(c("SampleID", "ClassNote")) %>%
  filter(ClassNote %in% groups)

testDataTb <- if (hasExternal) {
  read_tsv("test.txt")
}else {
  read_tsv("../preprocess_0/test.txt")
}
testData <- testDataTb %>%
  gather("SampleID", "Value", -Metabolite) %>%
  spread(Metabolite, "Value") %>%
  select(originalColumnNames) %>%
  inner_join(testSampleInfo, by = c("SampleID")) %>%
  column_to_rownames("SampleID")

train_cont <- trainControl(method = "repeatedcv", search = "random")
enRs <- train(ClassNote ~ ., data = trainData, method = "glmnet", trControl = train_cont)

varImp <- varImp(enRs, scale = T)
varImpDf <- varImp %>%
  .$importance %>%
  rownames_to_column("Metabolite") %>%
  as_tibble() %>%
  rename(VarImp = Overall) %>%
  arrange(desc(VarImp)) %>%
  mutate(Metabolite = str_replace_all(Metabolite, "`", ""))
write_csv(varImpDf, "EN_VarImp.csv")

predData <- predict(enRs, testData)
prob <- predict(enRs, testData, type = "prob")

predDf1 <- prob %>%
  as.data.frame(check.names = F, stringsAsFactors = F) %>%
  mutate(SampleID=rownames(testData)) %>%
  rowwise() %>%
  do({
    result <- as.data.frame(.)
    values <- result[1,] %>%
      select(-c("SampleID")) %>%
      unlist()
    result$Value <- values[1]
    result
  }) %>%
  select(c("SampleID", "Value")) %>%
  add_column(Prediction = predData)
predictFinalDf1 <- testSampleInfo %>%
  left_join(predDf1, by = c("SampleID"))
write_tsv(predictFinalDf1, "EN_Classification_Result.txt")

predDf <- prob %>%
  as.data.frame(check.names = F, stringsAsFactors = F) %>%
  mutate(SampleID=rownames(testData)) %>%
  rowwise() %>%
  do({
    result <- as.data.frame(.)
    values <- result[1,] %>%
      select(-c("SampleID")) %>%
      unlist()
    result$Probability <- max(values)
    result
  }) %>%
  select(c("SampleID", "Probability")) %>%
  add_column(Prediction = predData)
predictFinalDf <- testSampleInfo %>%
  inner_join(predDf, by = c("SampleID")) %>%
  rename(Sample = SampleID) %>%
  select(-c("Probability"), "Probability")
write_csv(predictFinalDf, "EN_Prediction.csv")

pre_summary = table(predictFinalDf$ClassNote, predictFinalDf$Prediction)

summaryTb <- pre_summary %>%
  as.data.frame() %>%
  as_tibble() %>%
  rename(Var1 = 1, Var2 = 2) %>%
  spread(Var2, "Freq")
summaryMatrix <- summaryTb %>%
  select(-"Var1") %>%
  as.matrix()
diagSum <- sum(diag(summaryMatrix))
sum <- sum(summaryMatrix)
predictive <- (diagSum / sum) %>%
  round(3)
finalSummaryTb <- summaryTb %>%
  mutate(`Model predictive accuracy` = c(predictive, "")) %>%
  rename(` ` = Var1)
write_csv(finalSummaryTb, "EN_Prediction_Summary.csv")