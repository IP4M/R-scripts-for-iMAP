# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/7/24

library(ggrepel)
library(ropls)
library(pROC)
library(egg)
library(randomForest)
library(Boruta)
library(magrittr)
library(optparse)
library(caret)
library(PRROC)
library(tidyverse)
library(extrafont)

createWhenNoExist <- function(f) {
  !dir.exists(f) && dir.create(f)
}

option_list <- list(
  make_option("--g", default = "SampleInfo.csv", type = "character", help = "sample group file"),
  make_option("--pc", default = "", type = "character", help = "config file"),
  make_option("--prefix", default = "", type = "character", help = "prefix")

)
opt <- parse_args(OptionParser(option_list = option_list))
font_import(paths = c("/usr/share/fonts/myFonts"),recursive =F, prompt = F)

args <- commandArgs(trailingOnly = F)
scriptPath <- dirname(sub("--file=", "", args[grep("--file", args)]))
source(str_c(scriptPath, "/base.R"))
source(str_c(scriptPath, "/fs_parse_config.R"))

options(digits = 3)

parent <- paste0("./")
createWhenNoExist(parent)

prefix <- opt$prefix

fileName <-getFileNameWithPrefix("Classification_Result.txt",prefix)

data <- read_tsv(fileName)

uniqGroup <- unique(data$ClassNote)
group1Data <- data %>%
  filter(ClassNote == uniqGroup[1])
group2Data <- data %>%
  filter(ClassNote == uniqGroup[2])


print("==========prRs==============")

print("group2Data")
print(group2Data$Value)
print("group1Data")

print(group1Data$Value)

prRs <- pr.curve(group2Data$Value, group1Data$Value, curve = T)

print(prRs)

auc <- prRs$auc.integral

print(auc)
if (auc < 0.5) {
  prRs <- pr.curve(group1Data$Value, group2Data$Value, curve = T)
  auc <- prRs$auc.integral
}

print("==========prDf==============")

prDf <- prRs$curve %>%
  as.data.frame() %>%
  set_colnames(c("Recall", "Precision", "Cutoff")) %>%
  select("Cutoff", everything())

print("==========prDataFileName==============")

prDataFileName<-getFileNameWithPrefix("PR_Curve_Data.csv",prefix)
write.csv(prDf,prDataFileName, row.names = F)

print("======plotConfigFileName=========")
#colors <- hsv(h = seq(0, 1, length = 100) * 0.8, s = 1, v = 1)
plotConfigFileName <- getFileNameWithPrefix(opt$pc, prefix)
plotConfigData <- read_tsv(plotConfigFileName, col_names = F, col_types = "cc") %>%
  set_colnames(c("arg", "value"))
colors <- getfinalColors(plotConfigData)
legendTitle <- configGet(plotConfigData, "legendTitle")
height <- configGet(plotConfigData, "height") %>%
  as.numeric()
width <- configGet(plotConfigData, "width") %>%
  as.numeric()
fontFamily <- configGet(plotConfigData, "fontFamily")
baseFamily <- fontFamily

yBreaks <- seq(0, 1, 0.2)

plotData <- prRs$curve %>%
  as.data.frame() %>%
  arrange(desc(V2), V1)

print("==================plotData===========")
plotData

p <- ggplot(data = plotData, aes(x = V1, y = V2, color = V3)) +
  theme_bw(base_size = 8.8, base_family = baseFamily) +
  theme(plot.title = element_text(size = 14, hjust = 0.5, face = "bold"), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), axis.title.x = element_text(size = 14), axis.title.y = element_text(size = 14),
        axis.text.x = element_text(size = 12), axis.text.y = element_text(size = 12),
        plot.margin = unit(c(1, 0.5, 1, 0.5), "cm"), panel.border = element_rect(size = 0.75),
        legend.text = element_text(size = 9), legend.title = element_text(size = 11)
  ) +
  geom_line() +
  xlab("FPR") +
  ylab("Sensitivity") +
  ggtitle(str_c("AUC=", format(auc, digits = 3))) +
  scale_x_continuous("Recall", breaks = yBreaks) +
  scale_y_continuous("Precision", breaks = seq(0, 1, 0.2), limit = c(0, 1)) +
  scale_colour_gradientn(colours = colors, breaks = yBreaks)

p <- getBasicPlotArg(p,plotConfigData)

print("==============p==================")

if (!is.na(legendTitle)) {
  p <- p +
    labs(colour = legendTitle)
}

pdfFileName <- getFileNameWithPrefix("PR_Curve.pdf", prefix)
ggsave(limitsize = FALSE, pdfFileName, p, width = width, height = height)






