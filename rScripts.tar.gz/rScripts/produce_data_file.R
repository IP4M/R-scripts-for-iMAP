# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/8/12
library(optparse)
library(magrittr)
library(tidyverse)

option_list <- list(
  make_option("--i", default = "AllMet1.csv", type = "character", help = "raw metabolite data file"),
  make_option("--config", default = "config.csv", type = "character", help = "config file")
)
opt <- parse_args(OptionParser(option_list = option_list))

configData <- read_tsv(opt$config, col_names = F) %>%
  set_colnames(c("arg", "value"))

configData

isNormal <- configData %>%
  filter(arg == "isNormal") %>%
  .$value == "T"

rawData <- read_csv("02_AllMet_Raw_Missing_Value_Filled.csv")

if (isNormal) {
  rawData <- read_csv("03_AllMet_Raw_NormArea.csv")
}

outData <- rawData %>%
  mutate(Raw_Metabolite = iconv(enc2utf8(Raw_Metabolite), sub = "byte")) %>%
  rename(Metabolite = Raw_Metabolite)

write.csv(outData, "04_AllMet.csv", row.names = F)


