# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/8/12
library(optparse)
library(magrittr)
library(tidyverse)

paretoNorm <- function(x) {
  (x - mean(x)) / sqrt(sd(x, na.rm = T))
}

option_list <- list(
  make_option("--cc", default = "calculate_config.txt", type = "character", help = "config file"),
  make_option("--si", default = "1;0", type = "character", help = "step and config arg index"),
  make_option("--g", default = "group.txt", type = "character", help = "sample group file")
)
opt <- parse_args(OptionParser(option_list = option_list))

args <- commandArgs(trailingOnly = F)
scriptPath <- dirname(sub("--file=", "", args[grep("--file", args)]))
source(str_c(scriptPath, "/base.R"))

calculateConfigData <- read_tsv(opt$cc, col_names = F, col_types = "cc") %>%
  set_colnames(c("arg", "value"))
calculateConfigData

standardMethods <- configGet(calculateConfigData, "standardMethods") %>%
  str_split(";") %>%
  unlist()

si <- opt$si %>%
  str_split(";") %>%
  unlist()
step <- si[1] %>%
  as.numeric()
index <- si[2] %>%
  as.numeric()

standardMethod <- standardMethods[index + 1]

data <- read_tsv(str_c(step - 1, ".result.txt")) %>%
  rename(Metabolite = 1)

tData <- data %>%
  mutate(Metabolite = factor(Metabolite, levels = unique(Metabolite))) %>%
  gather("SampleID", "Value", -Metabolite, factor_key = T) %>%
  spread(Metabolite, "Value")

outTData <- if (standardMethod == "scale") {
  tData %>%
    mutate_at(vars(-"SampleID"), function (x){
      scale(x)
    })
}else if (standardMethod == "center") {
  tData %>%
    mutate_at(vars(-"SampleID"), function(x) {
      scale(x, scale = F, center = T)
    })
}else {
  tData %>%
    mutate_at(vars(-"SampleID"), function(x) {
      paretoNorm(x)
    })
}

outTData

outData <- outTData %>%
  gather("Metabolite", "Value", -SampleID, factor_key = T) %>%
  spread(SampleID, "Value")

write_tsv(outData, str_c(step, ".result.txt"))
write_csv(outData, str_c(step, ".standard.csv"))








