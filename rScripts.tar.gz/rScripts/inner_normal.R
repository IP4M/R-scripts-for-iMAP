# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/8/12
library(optparse)
library(magrittr)
library(impute)
library(tidyverse)
library(NormalizeMets)
library(FitAR)

option_list <- list(
  make_option("--cc", default = "calculate_config.txt", type = "character", help = "config file"),
  make_option("--si", default = "1;0", type = "character", help = "step and config arg index"),
  make_option("--g", default = "group.txt", type = "character", help = "sample group file")
)
opt <- parse_args(OptionParser(option_list = option_list))

args <- commandArgs(trailingOnly = F)
scriptPath <- dirname(sub("--file=", "", args[grep("--file", args)]))
source(str_c(scriptPath, "/base.R"))

calculateConfigData <- read_tsv(opt$cc, col_names = F, col_types = "cc") %>%
  set_colnames(c("arg", "value"))
calculateConfigData

rowNames <- configGet(calculateConfigData, "rowNames") %>%
  str_split(";") %>%
  unlist()
multiples <- configGet(calculateConfigData, "multiples") %>%
  str_split(";") %>%
  unlist()

si <- opt$si %>%
  str_split(";") %>%
  unlist()
step <- si[1] %>%
  as.numeric()
index <- si[2] %>%
  as.numeric()

rowName <- rowNames[index + 1]
rateStr <- multiples[index + 1]

data <- read_tsv(str_c(step - 1, ".result.txt")) %>%
  rename(Metabolite = 1)

rate <- if (rateStr == "mean") {
  rs<-data %>%
    select_at(vars(!starts_with("QC"), -"Metabolite")) #%>%
    summarise_all(function(x) {
      sum(x, na.rm = T)
    }) %>%
    mutate(mean = rowMeans(.)) %>%
    .$mean
  rs
}else {
  rateStr %>%
    as.numeric()
}
data
index <- which(data$Metabolite == rowName)
index
outData <- data %>%
  mutate_at(vars(-c("Metabolite")), function(x) {
    (x * rate) / x[index]
  })

outData

write_tsv(outData, str_c(step, ".result.txt"))
write_csv(outData, str_c(step, ".inner_normal.csv"))








