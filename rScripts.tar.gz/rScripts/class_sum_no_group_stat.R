# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/6/18

myStartsWith <- function(str, prefix) {
  substring(str, 1, nchar(prefix)) == prefix
}

library(optparse)
library(ropls)
library(magrittr)
library(RColorBrewer)
library(scales)
library(tidyverse)

option_list <- list(
  make_option("--i", default = "AllMet_with_Anno.csv", type = "character", help = "metabolite data file"),
  make_option("--g", default = "SampleInfo.csv", type = "character", help = "sample group file"),
  make_option("--mc", default = "meta_color.txt", type = "character", help = "metabolite color file"),
  make_option("--sc", default = "sample_color.txt", type = "character", help = "sample color file"),
  make_option("--cp", default = "", type = "character", help = "compare info ")
)
opt <- parse_args(OptionParser(option_list = option_list))

data <- read_csv(opt$i) %>%
  select(-c("HMDB", "KEGG", "Metabolite"))

noOthersDf <- data %>%
  group_by(Class) %>%
  summarise_all(sum) %>%
  rowwise() %>%
  do({
    result <- as_tibble(.)
    data <- result %>%
      select(-c("Class"))
    result$sum <- sum(data)
    result
  }) %>%
  ungroup() %>%
  select(c("Class", "sum")) %>%
  mutate(percent = sum * 100 / (sum(sum)))

outDf <- noOthersDf %>%
  arrange(desc(percent)) %>%
  rename(`percent(%)` = percent)
outDf
write_csv(outDf, "Class_Table_Stat.csv")
