# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/6/18

library(gplots)
library(Hmisc)
library(optparse)
library(ropls)
library(magrittr)
library(ComplexHeatmap)
library(tools)
library(tidyverse)

option_list <- list(
  make_option("--config", default = "calculate_config.txt", type = "character", help = "config file")
)
opt <- parse_args(OptionParser(option_list = option_list))

args <- commandArgs(trailingOnly = F)
scriptPath <- dirname(sub("--file=", "", args[grep("--file", args)]))
source(str_c(scriptPath, "/base.R"))

createWhenNoExist <- function(f) {
  !dir.exists(f) && dir.create(f)
}

outTb<-read_csv("Network_Nodes_for_Cytoscape.csv") %>%
  rename(Metabolite = 1) %>%
  select(c("Metabolite"))

write_csv(outTb, "Diff_Metabolite.csv")


