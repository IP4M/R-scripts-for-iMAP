# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/7/24

library(ropls)
library(optparse)
library(tidyverse)
library(magrittr)

createWhenNoExist <- function(f) {
  !dir.exists(f) && dir.create(f)
}

configGet <- function(configData, key) {
  configData %>%
    filter(arg == key) %>%
    .$value
}

option_list <- list(
  make_option("--i", default = "AllMet_Raw.txt", type = "character", help = "metabolite data file"),
  make_option("--g", default = "group.txt", type = "character", help = "sample group file"),
  make_option("--sc", default = "sample_color.txt", type = "character", help = "sample color file"),
  make_option("--cc", default = "calculate_config.txt", type = "character", help = "config file")
)
opt <- parse_args(OptionParser(option_list = option_list))

calculateConfigData <- read_tsv(opt$cc, col_names = F, col_types = "cc") %>%
  set_colnames(c("arg", "value"))

vipNum <- configGet(calculateConfigData, "vip") %>%
  as.numeric()

sampleInfo <- read_tsv(opt$g) %>%
  rename(SampleID = Sample) %>%
  select(c("SampleID", "ClassNote"))

inputData <- read_tsv(opt$i) %>%
  rename(Metabolite = 1)

options(digits = 3)

sampleIds <- sampleInfo %>%
  .$SampleID

tmpData <- inputData %>%
  select(c("Metabolite", sampleIds))

data <- tmpData %>%
  gather("SampleID", "Value", -Metabolite) %>%
  spread(Metabolite, "Value") %>%
  inner_join(sampleInfo, by = c("SampleID"))

classNotes <- unique(sampleInfo$ClassNote)
cn <- combn(classNotes, 2)
for (i in 1:ncol(cn)) {
  load("oplsda.RData")

  method <- "pearson"
  pData <- plsdaRs@suppLs[["xModelMN"]] %>%
    as.data.frame() %>%
    summarise_all(function(x) { cor.test(x, plsdaRs@scoreMN, method = method)$p.value }) %>%
    unlist()
  vipVn = getVipVn(plsdaRs)
  corData <- cor(plsdaRs@suppLs[["xModelMN"]], plsdaRs@scoreMN, method = method) %>%
    as.data.frame() %>%
    .$p1

  classData <- inputData %>%
    select(c("Metabolite"))
  vipData <- data.frame(VIP = vipVn, Corr.Coeffs. = corData, P = pData) %>%
    rownames_to_column("Metabolite")
  allData <- classData %>%
    inner_join(vipData, by = c("Metabolite")) %>%
    mutate(FDR = p.adjust(P, method = "fdr")) %>%
    arrange(desc(VIP))
  parent <- "./"
  createWhenNoExist(parent)
  allFileName <- paste0(parent, "/OPLSDA_VIP.csv")
  write.csv(allData, allFileName, row.names = FALSE)

  diffData <- allData %>%
    filter(VIP >= vipNum) %>%
    select(c("Metabolite"))

  write_csv(diffData, "Diff_Metabolite.csv")


}







