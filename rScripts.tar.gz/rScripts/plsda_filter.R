# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/6/18

# library(MetaboAnalystR)
library(ropls)
library(plyr)
library(magrittr)
library(optparse)
library(tidyverse)

createWhenNoExist <- function(f) {
  !dir.exists(f) && dir.create(f)
}

option_list <- list(
  make_option("--cc", default = "calculate_config.txt", type = "character", help = "config file")
)
opt <- parse_args(OptionParser(option_list = option_list))

args <- commandArgs(trailingOnly = F)
scriptPath <- dirname(sub("--file=", "", args[grep("--file", args)]))
source(str_c(scriptPath, "/base.R"))

calculateConfigData <- read_tsv(opt$cc, col_names = F, col_types = "cc") %>%
  set_colnames(c("arg", "value"))

vip <- configGet(calculateConfigData, "vip") %>%
  as.numeric()

data <- read_csv("PLSDA_VIP.csv") %>%
  filter(VIP >= vip) %>%
  select(c("Metabolite"))

write_csv(data, "Diff_Metabolite.csv")




