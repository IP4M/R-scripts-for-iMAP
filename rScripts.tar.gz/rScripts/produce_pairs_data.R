# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/8/12
library(optparse)
library(magrittr)
library(tidyverse)

option_list <- list(
  make_option("--i", default = "AllMet1.csv", type = "character", help = "raw metabolite data file")
)
opt <- parse_args(OptionParser(option_list = option_list))

data <- read.csv(opt$i, header = T, stringsAsFactors = F)

cData <- data %>%
  select(-c("Class"))

head(cData)

pairData <- read_tsv("pairInfo.txt", col_names = F)

pairData

pairData <- if (nrow(pairData) > 0) {
  pairData %>%
    set_colnames(c("Metabolite")) %>%
    mutate(Class = "Reaction Ratio") %>%
    mutate(KEGG = NA, HMDB = NA) %>%
    select(c("Class", "HMDB", "KEGG", "Metabolite")) %>%
    rowwise() %>%
    do({
         result <- as.data.frame(.)
         name <- result[1, "Metabolite"] %>% as.character()
         pro <- unlist(strsplit(name, "/"))[1]
         sub <- unlist(strsplit(name, "/"))[2]
         subDf <- cData %>%
           filter(KEGG == sub) %>%
           rowwise() %>%
           do({
                result <- as_tibble(.)
                data <- result %>%
                  select(-c("HMDB", "KEGG", "Metabolite")) %>%
                  unlist()
                sum <- sum(data)
                result %>% mutate(rowSum = sum)
              }) %>%
           ungroup() %>%
           arrange(desc(rowSum)) %>%
           head(1) %>%
           select(-"rowSum")

         subData <- subDf %>%
           select(-c("KEGG", "HMDB", "Metabolite"))
         proDf <- cData %>%
           filter(KEGG == pro) %>%
           rowwise() %>%
           do({
                result <- as_tibble(.)
                data <- result %>%
                  select(-c("HMDB", "KEGG", "Metabolite")) %>%
                  unlist()
                sum <- sum(data)
                result %>% mutate(rowSum = sum)
              }) %>%
           ungroup() %>%
           arrange(desc(rowSum)) %>%
           head(1) %>%
           select(-"rowSum")
         proData <- proDf %>%
           select(-c("KEGG", "HMDB", "Metabolite"))
         divData <- proData / subData
         result <- cbind(result, divData)
         result$HMDB <- str_c(proDf$HMDB, "/", subDf$HMDB)
         result$KEGG <- str_c(proDf$KEGG, "/", subDf$KEGG)
         result$Metabolite <- str_c(proDf$Metabolite, "/", subDf$Metabolite)
         result
       })
}else {
  cData %>%
    filter(FALSE) %>%
    add_column(Class = NA) %>%
    select(c("Class", "HMDB", "KEGG", "Metabolite"), everything())
}


pairData

head(pairData, 40)
write.csv(pairData, "05_Ratio_Raw.csv", row.names = F)

distPairData <- if (nrow(pairData) > 0) {
  pairData %>%
    as_tibble() %>%
    mutate(distName = Metabolite %>%
      map_chr(~.x %>%
        str_split("/") %>%
        unlist() %>%
        sort() %>%
        str_c(collapse = ";"))) %>%
    distinct(distName, .keep_all = T) %>%
    select(-c("distName"))
}else pairData

allData <- rbind(data, distPairData)

write.csv(allData, "06_AllMet_and_Ratio.csv", row.names = F)



