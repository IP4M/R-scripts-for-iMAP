# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/8/12
library(optparse)
library(magrittr)
library(impute)
library(tidyverse)

option_list <- list(
  make_option("--cc", default = "calculate_config.txt", type = "character", help = "config file"),
  make_option("--si", default = "1;0", type = "character", help = "step and config arg index")
)
opt <- parse_args(OptionParser(option_list = option_list))

si <- opt$si %>%
  str_split(";") %>%
  unlist()
step <- si[1]  %>%
  as.numeric()

data <- read_tsv(str_c(step-1, ".result.txt")) %>%
  rename(Metabolite = 1)

outData <- data

write_tsv(outData, str_c(step, ".result.txt"))







