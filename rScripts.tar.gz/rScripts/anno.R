# Title     : TODO
# Objective : TODO
# Created by: yz
# Created on: 14/8/2020
library(tidyverse)

rawData <- read_tsv("AllMet_Raw.txt") %>%
  rename(Metabolite = 1)

keggInfoData <- read_tsv("keggInfo.txt") %>%
  select(c("Class", "HMDB", "KEGG", "Raw_Metabolite")) %>%
  rename(HMDB = HMDB, KEGG = KEGG)

lowerKeggData <- keggInfoData %>%
  mutate(lowerName = tolower(Raw_Metabolite)) %>%
  select(-c("Raw_Metabolite"))

rawDataColumn <- rawData %>%
  select(-c("Metabolite"))

finalColumnNames <- c("Class", "HMDB", "KEGG", "Metabolite")
finalColumnNames <- c(finalColumnNames, colnames(rawDataColumn))

outData <- rawData %>%
  mutate(Metabolite = iconv(enc2utf8(Metabolite), sub = "byte")) %>%
  mutate(lowerName = tolower(Metabolite)) %>%
  left_join(lowerKeggData, by = c("lowerName")) %>%
  select(-c("lowerName")) %>%
  select(finalColumnNames) %>%
  mutate_at(vars("Class"), function(x) {
    replace_na(x, "Unknown")
  })

outData

write_csv(outData, "AllMet_with_Anno.csv")

write_tsv(outData, "AllMet_with_Anno.txt")
