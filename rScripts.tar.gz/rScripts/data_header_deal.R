# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/8/12
library(optparse)
library(magrittr)
library(tidyverse)

option_list <- list(
  make_option("--i", default = "AllMet1.csv", type = "character", help = "raw metabolite data file")
)
opt <- parse_args(OptionParser(option_list = option_list))


data <- read_tsv(opt$i) %>%
  rename(Raw_Metabolite = 1)

data

write_csv(data, "test.csv")



