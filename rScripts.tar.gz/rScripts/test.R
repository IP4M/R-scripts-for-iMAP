# Title     : TODO
# Objective : TODO
# Created by: Administrator
# Created on: 2019/8/12
library(optparse)
library(magrittr)
library(impute)
library(tidyverse)
library(NormalizeMets)
library(FitAR)

option_list <- list(
  make_option("--cc", default = "calculate_config.txt", type = "character", help = "config file"),
  make_option("--si", default = "1;0", type = "character", help = "step and config arg index"),
  make_option("--g", default = "group.txt", type = "character", help = "sample group file")
)
opt <- parse_args(OptionParser(option_list = option_list))

args <- commandArgs(trailingOnly = F)
scriptPath <- dirname(sub("--file=", "", args[grep("--file", args)]))
source(str_c(scriptPath, "/base.R"))

data <- tibble(x=1:5,y=6:10)
data
outData<-data %>%
  rowwise() %>%
  mutate_all(function (x){
    x/x[2]
  })
outData






