# Title     : TODO
# Objective : TODO
# Created by: yz
# Created on: 2018/3/1

library(optparse)
library(magrittr)
library(viridis)
library(tidyverse)
option_list <- list(
  make_option("--base", default = "metabo_base.R", type = "character", help = "metabo base R file"),
  make_option("--d", type = 'character', action = "store", default = "", help = "the database direcotry"),
  make_option("--config", default = "calculate_config.txt", type = "character", help = "config file"),
  make_option("--g", default = "SampleInfo.csv", type = "character", help = "sample group file")
)
opt <- parse_args(OptionParser(option_list = option_list))

createWhenNoExist <- function(f) {
  !dir.exists(f) && dir.create(f)
}

args <- commandArgs(trailingOnly = F)
scriptPath <- dirname(sub("--file=", "", args[grep("--file", args)]))
source(str_c(scriptPath, "/base.R"))

fileName <- "name_map.txt"

if (!file.exists(fileName)) {
  quit(status = 0)
}

diffData <- read_csv("AllMet_with_Anno.csv")

nameMapDf <- read_tsv(fileName)
keggIds <- nameMapDf$KEGG
if (all(is.na(keggIds))) {
  quit(status = 0)
}

parent <- "./Sig_Pathways_ID"
createWhenNoExist(parent)

nameParent <- "./Sig_Pathways_Name"
createWhenNoExist(nameParent)

data <- read_csv("Pathway_Result.csv") %>%
  rename(Metabolite = X1)

head(data)
names <- data$Metabolite

configData <- read_tsv(opt$config, col_names = F) %>%
  set_colnames(c("arg", "value"))

fcData <- read_tsv("fc_color.txt")

print(fcData)

load("kegg_enrich.RData")
for (name in names) {
  PlotMetpaPath(mSet, name, 10, 8, parent = parent, dataDir = opt$d, fcData = fcData)
  PlotMetpaPathByName(mSet, name, 10, 8, parent = nameParent, dataDir = opt$d, fcData = fcData, diffData = diffData)
}










