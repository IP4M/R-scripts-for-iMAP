# Title     : TODO
# Objective : TODO
# Created by: yz
# Created on: 2018/6/8
library(optparse)
library(magrittr)
library(tidyr)
library(tibble)
library(tidyverse)

option_list <- list(
make_option("--t", type = 'character', action = "store", default = "Metabolite", help = "input metabolite ID type"),
make_option("--d", type = 'character', action = "store", default = "./", help = "the database direcotry"),
make_option("--base", default = "metabo_base.R", type = "character", help = "metabo base R file")
)
opt <- parse_args(OptionParser(option_list = option_list))

args <- commandArgs(trailingOnly = F)
scriptPath <- dirname(sub("--file=", "", args[grep("--file", args)]))
source(str_c(scriptPath, "/base.R"))

diffData <- read_csv("AllMet_with_Anno.csv")

if (nrow(diffData) == 0) {
    quit(status = 0)
}

diffKeggs <- diffData %>%
    .$KEGG %>%
    map(function(x){
        str_split(x, "/") %>% unlist()
    }) %>%
    flatten_chr()
diffKeggs

cmpd.vec <- diffKeggs
mSet <- InitDataObjects("conc", "msetora", FALSE)
mSet <- Setup.MapData(mSet, cmpd.vec);
mSet <- CrossReferencing(mSet, "kegg", dataDir = opt$d)
mSet <- CreateMappingResultTable(mSet, dataDir = opt$d)
save(mSet, file = "idMapping_mSet.RData")

