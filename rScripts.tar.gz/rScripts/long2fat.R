# Title     : TODO
# Objective : TODO
# Created by: yz
# Created on: 17/7/2020

library(tidyverse)

data <- read_csv("input.csv")

outTb <- data %>%
  spread(2, 3)

write_csv(outTb, "output.csv")

print(data)
print(outTb)