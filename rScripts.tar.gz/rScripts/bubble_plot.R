# Title     : TODO
# Objective : TODO
# Created by: yz
# Created on: 2018/3/1

library(optparse)
library(magrittr)
library(tidyverse)
library(extrafont)

option_list <- list(
  make_option("--base", default = "metabo_base.R", type = "character", help = "metabo base R file"),
  make_option("--pc", default = "", type = "character", help = "config file")

)
opt <- parse_args(OptionParser(option_list = option_list))
font_import(paths = c("/usr/share/fonts/myFonts"),recursive =F, prompt = F)

args <- commandArgs(trailingOnly = F)
scriptPath <- dirname(sub("--file=", "", args[grep("--file", args)]))
source(str_c(scriptPath, "/base.R"))
source(str_c(scriptPath, "/parse_config.R"))
fontFamily <- configGet(plotConfigData, "fontFamily")
baseFamily <- fontFamily
resultFile <- "Pathway_Result.csv"

if (!file.exists(resultFile)) {
  quit(status = 0)
}

load("kegg_enrich.RData")

df <- read_csv(resultFile)
if (nrow(df) == 0) {
  quit(status = 0)
}

x <- mSet$analSet$ora.mat[, 8]
y <- mSet$analSet$ora.mat[, 4]
names(x) <- names(y) <- rownames(mSet$analSet$ora.mat)
y = -log(y)
inx <- order(y, decreasing = T)
x <- x[inx]
y <- y[inx]
sqx <- sqrt(x)
min.x <- min(sqx, na.rm = TRUE)
max.x <- max(sqx, na.rm = TRUE)
if (min.x == max.x) {
  max.x = 1.5 * max.x
  min.x = 0.5 * min.x
}
maxR <- (max.x - min.x) / 40
minR <- (max.x - min.x) / 160

radi.vec <- minR + (maxR - minR) * (sqx - min.x) / (max.x -
  min.x)
bg.vec <- heat.colors(length(y))
path.nms <- names(metpa$path.ids)[match(names(x), metpa$path.ids)]
bg = "white"
imgName = "Pathway_Bubbleplot.pdf"
if (is.na(width)) {
  w <- 7
}else if (width == 0) {
  w <- 7
}else {
  w <- width
}
h <- w
path.overview <- imgName

width.px <- height.px <- w * 72
circleInfo <- CalculateCircleInfo(x, y,
                                  radi.vec, width.px, height.px, path.nms)

plotData <- tibble(x = x, y = y, name = path.nms, r = radi.vec, color = bg.vec) %>%
  arrange(r) %>%
  mutate(pointSize = r * 400) %>%
  filter(is.finite(r))

print(plotData)

if (nrow(plotData) == 0) {
  quit(status = 0)
}

cols <- plotData %>%
  select(c("name", "color")) %>%
  deframe()
nameData <- plotData %>%
  filter(y >= -log(0.05))
p <- ggplot(plotData, aes(x = x, y = y, size = r, fill = name)) +
  theme_classic(base_size = 8.8) +
  theme(axis.text.x = element_text(size = 12, vjust = 0.5),
        axis.text.y = element_text(size = 12), legend.position = 'none',
        axis.title.y = element_text(size = 12), legend.margin = margin(t = 0.3, b = 0.1, unit = 'cm'),
        legend.text = element_text(size = 6), axis.title.x = element_text(size = 12),
        plot.margin = unit(c(1, 1, 1, 1), "cm"), panel.grid.major = element_line(colour = "#BEBEBE",
                                                                                 linetype = 2, size = 0.15,),
        panel.grid.minor = element_blank(),
  ) +
  xlab("Pathway Impact") +
  ylab("-ln(p)") +
  geom_point(pch = 21, colour = "black") +
  geom_text_repel(segment.size = 0.2, data = nameData, aes(x = x, y = y, label = name), size = 2, family = baseFamily,
                  color = "black") +
  scale_fill_manual("", values = cols) +
  scale_radius(range = c(min(plotData$pointSize), max(plotData$pointSize)), name = "")

p <- getBasicPlotArg(p)

ggsave(limitsize = FALSE, imgName, p, width = width, height = height)





