# Title     : TODO
# Objective : TODO
# Created by: yz
# Created on: 4/9/2020

getParentNode <- function(pns) {
  pns %>%
    str_split(";") %>%
    unlist() %>%
    head(1)
}

getCalculateArg <- function(calculateConfigData, fieldName, index) {
  configGet(calculateConfigData, fieldName) %>%
    str_split(";") %>%
    unlist() %>%
    .[index + 1]
}

getfinalColors <- function(plotConfigData) {
  colorsStr <- configGet(plotConfigData, "colorsStr")
  customColors <- configGet(plotConfigData, "customColors")
  finalColorsStr <- if (colorsStr == "custom") {
    customColors
  } else {
    colorsStr
  }
  finalColors <- str_split(finalColorsStr, ":") %>%
    unlist()
  finalColors
}

getBasicPlotArg <- function(p,plotConfigData) {
  xTitleFont <- configGet(plotConfigData, "xTitleFont")
  yTitleFont <- configGet(plotConfigData, "yTitleFont")
  xFont <- configGet(plotConfigData, "xFont")
  yFont <- configGet(plotConfigData, "yFont")
  legendFont <- configGet(plotConfigData, "legendFont")
  legendTitleFont <- configGet(plotConfigData, "legendTitleFont")
  mainTitleFont <- configGet(plotConfigData, "mainTitleFont")
  mainTitle <- configGet(plotConfigData, "mainTitle")
  p <- p +
    theme(plot.title = element_text(hjust = 0.5, size = mainTitleFont), legend.text = element_text(size = legendFont),
          legend.title = element_text(size = legendTitleFont), axis.text.x = element_text(size = xFont),
          axis.title.x = element_text(size = xTitleFont), axis.text.y = element_text(size = yFont),
          axis.title.y = element_text(size = yTitleFont))

  if (!is.na(mainTitle)) {
    p <- p + ggtitle(mainTitle)
  }
  p
}



